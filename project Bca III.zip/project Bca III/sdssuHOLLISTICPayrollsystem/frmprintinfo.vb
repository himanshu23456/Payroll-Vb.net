﻿Public Class frmprintinfo

    Private Sub GenPayFinalBindingNavigatorSaveItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Me.Validate()
        Me.GenPayFinalBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.GenerallPayrollDataSet)

    End Sub

    Private Sub frmprintinfo_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'GenerallPayrollDataSet.GenPayFinal' table. You can move, or remove it, as needed.
        Me.GenPayFinalTableAdapter.Fill(Me.GenerallPayrollDataSet.GenPayFinal)

    End Sub

    Private Sub Label1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub



    Private Sub PrintDocument1_PrintPage(ByVal sender As System.Object, ByVal e As System.Drawing.Printing.PrintPageEventArgs) Handles PrintDocument1.PrintPage
        e.Graphics.DrawString(txtReceipt1.Text, Font, Brushes.Black, 140, 140)
        e.Graphics.DrawImage(Me.PictureBox3.Image, 186, 111, PictureBox3.Width - 15, PictureBox3.Height - 25)

    End Sub


    Private Sub TextBox14_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox14.TextChanged
        Me.GenPayFinalBindingSource.Filter = "PlantID LIKE '" & TextBox14.Text & "%'"
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        GenPayFinalBindingSource.MovePrevious()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        GenPayFinalBindingSource.MoveNext()
    End Sub

    Private Sub Button12_Click(sender As Object, e As EventArgs) Handles Button12.Click

        BasicTextBox.Text = FormatCurrency(BasicTextBox.Text)
        txtReceipt1.Text = ""
        txtReceipt1.AppendText("" + vbNewLine)
        txtReceipt1.AppendText("" + vbNewLine)
        txtReceipt1.AppendText("" + vbNewLine)
        txtReceipt1.AppendText("" + vbNewLine)
        txtReceipt1.AppendText("" + vbNewLine)
        txtReceipt1.AppendText("" + vbNewLine)
        txtReceipt1.AppendText("" + vbNewLine)
        txtReceipt1.AppendText("Employee Name: " + vbTab & EmployeeNameTextBox.Text + vbNewLine)
        txtReceipt1.AppendText("Address: " + vbTab + vbTab & AddressTextBox.Text + vbNewLine)
        txtReceipt1.AppendText("Contact: " + vbTab + vbTab & ContactNumberTextBox.Text + vbNewLine)
        txtReceipt1.AppendText("Email: " + vbTab + vbTab + vbTab & EmailTextBox.Text + vbNewLine)
        txtReceipt1.AppendText("Blood Type: " + vbTab + vbTab & BloodTypeTextBox.Text + vbNewLine)
        txtReceipt1.AppendText("Designation: " + vbTab + vbTab & DesignationTextBox.Text + vbNewLine)
        txtReceipt1.AppendText("Position: " + vbTab + vbTab & PositionTextBox.Text + vbNewLine)
        txtReceipt1.AppendText("Basic Salary: " + vbTab + vbTab & BasicTextBox.Text + vbNewLine)
        txtReceipt1.AppendText("Date of Origin: " + vbTab + vbTab & DateofOriginTextBox.Text + vbNewLine)

        txtReceipt1.AppendText("" + vbNewLine)
        txtReceipt1.AppendText("= = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = " + vbNewLine)
        txtReceipt1.AppendText("                                             Special Thanks TMT                    " + vbNewLine)
        txtReceipt1.AppendText("= = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = " + vbNewLine)

        PrintPreviewDialog1.ShowDialog()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click

        Me.TableAdapterManager.UpdateAll(Me.GenerallPayrollDataSet)
        Me.Close()

    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick

    End Sub
End Class