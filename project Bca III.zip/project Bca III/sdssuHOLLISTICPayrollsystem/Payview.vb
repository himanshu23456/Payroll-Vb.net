﻿Public Class Payview

    Private Sub GenPayFinalBindingNavigatorSaveItem_Click(sender As Object, e As EventArgs) Handles GenPayFinalBindingNavigatorSaveItem.Click
        Me.Validate()
        Me.GenPayFinalBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.GenerallPayrollDataSet)

    End Sub

    Private Sub Payview_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'GenerallPayrollDataSet.GenPayFinal' table. You can move, or remove it, as needed.
        Me.GenPayFinalTableAdapter.Fill(Me.GenerallPayrollDataSet.GenPayFinal)

    End Sub

    Private Sub TextBox14_TextChanged(sender As Object, e As EventArgs) Handles TextBox14.TextChanged
        Me.GenPayFinalBindingSource.Filter = "PlantID LIKE '" & TextBox14.Text & "%'"
    End Sub

    Private Sub btnRemove_Click(sender As Object, e As EventArgs) Handles btnRemove.Click
        GenPayFinalBindingSource.RemoveCurrent()
    End Sub

    Private Sub Button12_Click(sender As Object, e As EventArgs) Handles Button12.Click
        Me.PrintForm1.PrintAction = Printing.PrintAction.PrintToPreview
        Me.PrintForm1.Print()
    End Sub

    Private Sub Panel1_Paint(sender As Object, e As PaintEventArgs) Handles Panel1.Paint

    End Sub
End Class