﻿Public Class About

    Private Sub Panel1_Paint(ByVal sender As System.Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles Panel1.Paint

    End Sub

   
    Private Sub save_Click(sender As Object, e As EventArgs) Handles save.Click
        Me.Hide()
    End Sub
End Class