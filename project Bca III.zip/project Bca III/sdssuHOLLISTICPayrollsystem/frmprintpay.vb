﻿Public Class frmprintpay

    Private Sub GenPayFinalBindingNavigatorSaveItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Me.Validate()
        Me.GenPayFinalBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.GenerallPayrollDataSet)

    End Sub

    Private Sub frmprintpay_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'GenerallPayrollDataSet.GenPayFinal' table. You can move, or remove it, as needed.
        Me.GenPayFinalTableAdapter.Fill(Me.GenerallPayrollDataSet.GenPayFinal)

    End Sub

    Private Sub GroupBox4_Enter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GroupBox4.Enter

    End Sub

    Private Sub PrintDocument1_PrintPage(ByVal sender As System.Object, ByVal e As System.Drawing.Printing.PrintPageEventArgs) Handles PrintDocument1.PrintPage
        e.Graphics.DrawString(txtReceipt.Text, Font, Brushes.Black, 140, 140)
        e.Graphics.DrawImage(Me.PictureBox1.Image, 186, 111, PictureBox1.Width - 15, PictureBox1.Height - 25)

    End Sub

    Private Sub Button9_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button9.Click
        Me.TableAdapterManager.UpdateAll(Me.GenerallPayrollDataSet)
        Me.Close()

    End Sub
    Private Sub TextBox14_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox14.TextChanged
        Me.GenPayFinalBindingSource.Filter = "PlantID LIKE '" & TextBox14.Text & "%'"
    End Sub

    Private Sub Button12_Click_1(sender As Object, e As EventArgs) Handles Button12.Click
        TotalDeductionTextBox.Text = Val(WtaxTextBox.Text) + Val(GSISPremiumTextBox.Text) + Val(GSISSalaryLoanTextBox.Text) + Val(GSISELTextBox.Text) + Val(GSISEMRGLTextBox.Text) + Val(GSISPLTextBox.Text) + Val(PagIbigPremTextBox.Text) + Val(PagIbigMLTextBox.Text) + Val(PagIbig2TextBox.Text) + Val(PhilHealthPremiunTextBox.Text) + Val(LEAPTextBox.Text) + Val(IGPTextBox.Text) + Val(FacultyUnionTextBox.Text) + Val(RefundDisallowTextBox.Text) + Val(TuitionTextBox.Text) + Val(LBPPaymentTextBox.Text) + Val(CitySavingsTextBox.Text)
        GrossAmountTextBox.Text = Val(BasicTextBox.Text) + Val(PERATextBox.Text)
        NetAmountTextBox.Text = Val(GrossAmountTextBox.Text) - Val(TotalDeductionTextBox.Text)

        NetAmountTextBox.Text = FormatCurrency(NetAmountTextBox.Text)
        TotalDeductionTextBox.Text = FormatCurrency(TotalDeductionTextBox.Text)
        GrossAmountTextBox.Text = FormatCurrency(GrossAmountTextBox.Text)

        txtReceipt.Text = ""
        txtReceipt.AppendText("" + vbNewLine)
        txtReceipt.AppendText("" + vbNewLine)
        txtReceipt.AppendText("" + vbNewLine)
        txtReceipt.AppendText("" + vbNewLine)
        txtReceipt.AppendText("" + vbNewLine)
        txtReceipt.AppendText("" + vbNewLine)
        txtReceipt.AppendText("" + vbNewLine)

        txtReceipt.AppendText(vbTab + vbTab + vbTab + vbTab + vbTab + vbTab & "PAY-SLIP" + vbNewLine)
        txtReceipt.AppendText("" + vbNewLine)
        txtReceipt.AppendText("" + vbNewLine)
        txtReceipt.AppendText("" + vbNewLine)
        txtReceipt.AppendText("Plantilla Number: " + vbTab & PlantIDTextBox.Text + vbTab + vbTab + vbTab + vbNewLine)
        txtReceipt.AppendText("Employee Name: " + vbTab & EmployeeNameTextBox.Text + vbTab + vbTab + vbNewLine)
        txtReceipt.AppendText("Number: " + vbTab + vbTab & NoTextBox.Text + vbNewLine)
        txtReceipt.AppendText("" + vbNewLine)
        txtReceipt.AppendText("" + vbNewLine)

        txtReceipt.AppendText("Basic Salary: " + vbTab & BasicTextBox.Text + vbNewLine)
        txtReceipt.AppendText("Pera: " + vbTab + vbTab & PERATextBox.Text + vbNewLine)
        txtReceipt.AppendText("Gross Amount: " + vbTab & GrossAmountTextBox.Text + vbNewLine)

        txtReceipt.AppendText("= = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = " + vbNewLine)

        txtReceipt.AppendText("" + vbNewLine)
        txtReceipt.AppendText(vbTab + vbTab & "Deductions" + vbNewLine)
        txtReceipt.AppendText("" + vbNewLine)
        txtReceipt.AppendText("W/ Tax: " + vbTab + vbTab + vbTab & WtaxTextBox.Text + vbNewLine)
        txtReceipt.AppendText("GSIS Premium: " + vbTab + vbTab & GSISPremiumTextBox.Text + vbNewLine)
        txtReceipt.AppendText("GSIS Salary Loan: " + vbTab & GSISSalaryLoanTextBox.Text + vbNewLine)
        txtReceipt.AppendText("GSIS EL: " + vbTab + vbTab & GSISELTextBox.Text + vbNewLine)
        txtReceipt.AppendText("GSIS EMRGL: " + vbTab + vbTab & GSISEMRGLTextBox.Text + vbNewLine)
        txtReceipt.AppendText("GSIS PL: " + vbTab + vbTab & GSISPLTextBox.Text + vbNewLine)
        txtReceipt.AppendText("Pag-Ibig Premium: " + vbTab & PagIbigPremTextBox.Text + vbNewLine)
        txtReceipt.AppendText("Pag-Ibig ML: " + vbTab + vbTab & PagIbigMLTextBox.Text + vbNewLine)
        txtReceipt.AppendText("Pag-Ibig 2: " + vbTab + vbTab & PagIbig2TextBox.Text + vbNewLine)
        txtReceipt.AppendText("Phil Health Premium:  " + vbTab & PhilHealthPremiunTextBox.Text + vbNewLine)
        txtReceipt.AppendText("LEAP: " + vbTab + vbTab + vbTab & LEAPTextBox.Text + vbNewLine)
        txtReceipt.AppendText("IGP: " + vbTab + vbTab + vbTab & IGPTextBox.Text + vbNewLine)
        txtReceipt.AppendText("Faculty Union: " + vbTab + vbTab & FacultyUnionTextBox.Text + vbNewLine)
        txtReceipt.AppendText("Refund Disallow: " + vbTab & RefundDisallowTextBox.Text + vbNewLine)
        txtReceipt.AppendText("Tuition: " + vbTab + vbTab + vbTab & TuitionTextBox.Text + vbNewLine)
        txtReceipt.AppendText("LBP Payment: " + vbTab + vbTab & LBPPaymentTextBox.Text + vbNewLine)
        txtReceipt.AppendText("City Savings: " + vbTab + vbTab & CitySavingsTextBox.Text + vbNewLine)

        txtReceipt.AppendText("" + vbNewLine)
        txtReceipt.AppendText("Total Deductions: " + vbTab & TotalDeductionTextBox.Text + vbTab + vbTab & "Net Amount: " + vbTab & NetAmountTextBox.Text + vbNewLine)
        txtReceipt.AppendText("= = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = " + vbNewLine)
        txtReceipt.AppendText(vbTab & "Due Date: " + Today & vbTab + vbTab + vbTab + vbTab + vbTab + vbTab & "Time: " & TimeOfDay + vbNewLine)
        txtReceipt.AppendText("= = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = " + vbNewLine)
        txtReceipt.AppendText("" + vbNewLine)
        txtReceipt.AppendText("" + vbNewLine)
        txtReceipt.AppendText("" + vbNewLine)
        txtReceipt.AppendText("" + vbNewLine)
        txtReceipt.AppendText(vbTab + "Recieve by:" + vbNewLine)
        txtReceipt.AppendText(vbTab + vbTab + vbTab + "___________________" + vbTab + vbNewLine)
        txtReceipt.AppendText(vbTab + vbTab + vbTab + EmployeeNameTextBox.Text + vbNewLine)
        txtReceipt.AppendText(vbTab + vbTab + vbTab + "          Employee" + vbNewLine)
        txtReceipt.AppendText("" + vbNewLine)
        txtReceipt.AppendText("" + vbNewLine)
        txtReceipt.AppendText("" + vbNewLine)
        txtReceipt.AppendText("= = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = " + vbNewLine)
        txtReceipt.AppendText("                                       Need Help?            Contact Us: 09096510899                                        " + vbNewLine)
        txtReceipt.AppendText("= = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = " + vbNewLine)
        PrintPreviewDialog1.ShowDialog()

    End Sub

    Private Sub Button4_Click_1(sender As Object, e As EventArgs) Handles Button4.Click
        GenPayFinalBindingSource.MovePrevious()
    End Sub

    Private Sub Button1_Click_1(sender As Object, e As EventArgs) Handles Button1.Click
        GenPayFinalBindingSource.MoveNext()
    End Sub

    
End Class