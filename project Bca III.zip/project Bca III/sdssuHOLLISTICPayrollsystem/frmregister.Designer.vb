﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmregister
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim PlantIDLabel As System.Windows.Forms.Label
        Dim EmployeeNameLabel As System.Windows.Forms.Label
        Dim AddressLabel As System.Windows.Forms.Label
        Dim ContactNumberLabel As System.Windows.Forms.Label
        Dim EmailLabel As System.Windows.Forms.Label
        Dim BloodTypeLabel As System.Windows.Forms.Label
        Dim DepartmentLabel As System.Windows.Forms.Label
        Dim DesignationLabel As System.Windows.Forms.Label
        Dim PositionLabel As System.Windows.Forms.Label
        Dim DateofOriginLabel As System.Windows.Forms.Label
        Dim BasicLabel As System.Windows.Forms.Label
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmregister))
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.BasicTextBox = New System.Windows.Forms.TextBox()
        Me.GenPayFinalBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.GenerallPayrollDataSet = New sdssuHOLLISTICPayrollsystem.GenerallPayrollDataSet()
        Me.DateofOriginDateTimePicker = New System.Windows.Forms.DateTimePicker()
        Me.PositionComboBox = New System.Windows.Forms.ComboBox()
        Me.DesignationComboBox = New System.Windows.Forms.ComboBox()
        Me.DepartmentComboBox = New System.Windows.Forms.ComboBox()
        Me.BloodTypeComboBox = New System.Windows.Forms.ComboBox()
        Me.EmailTextBox = New System.Windows.Forms.TextBox()
        Me.ContactNumberTextBox = New System.Windows.Forms.TextBox()
        Me.AddressTextBox = New System.Windows.Forms.TextBox()
        Me.EmployeeNameTextBox = New System.Windows.Forms.TextBox()
        Me.PlantIDTextBox = New System.Windows.Forms.TextBox()
        Me.GenPayFinalTableAdapter = New sdssuHOLLISTICPayrollsystem.GenerallPayrollDataSetTableAdapters.GenPayFinalTableAdapter()
        Me.TableAdapterManager = New sdssuHOLLISTICPayrollsystem.GenerallPayrollDataSetTableAdapters.TableAdapterManager()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.btnLogin = New System.Windows.Forms.Button()
        Me.Button9 = New System.Windows.Forms.Button()
        Me.save = New System.Windows.Forms.Button()
        Me.btnDeleteJHS = New System.Windows.Forms.Button()
        Me.LinkLabel1 = New System.Windows.Forms.LinkLabel()
        Me.Button5 = New System.Windows.Forms.Button()
        PlantIDLabel = New System.Windows.Forms.Label()
        EmployeeNameLabel = New System.Windows.Forms.Label()
        AddressLabel = New System.Windows.Forms.Label()
        ContactNumberLabel = New System.Windows.Forms.Label()
        EmailLabel = New System.Windows.Forms.Label()
        BloodTypeLabel = New System.Windows.Forms.Label()
        DepartmentLabel = New System.Windows.Forms.Label()
        DesignationLabel = New System.Windows.Forms.Label()
        PositionLabel = New System.Windows.Forms.Label()
        DateofOriginLabel = New System.Windows.Forms.Label()
        BasicLabel = New System.Windows.Forms.Label()
        Me.GroupBox1.SuspendLayout()
        CType(Me.GenPayFinalBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.GenerallPayrollDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'PlantIDLabel
        '
        PlantIDLabel.AutoSize = True
        PlantIDLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        PlantIDLabel.Font = New System.Drawing.Font("Century Schoolbook", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        PlantIDLabel.Location = New System.Drawing.Point(21, 43)
        PlantIDLabel.Name = "PlantIDLabel"
        PlantIDLabel.Size = New System.Drawing.Size(80, 21)
        PlantIDLabel.TabIndex = 0
        PlantIDLabel.Text = "Plant ID:"
        '
        'EmployeeNameLabel
        '
        EmployeeNameLabel.AutoSize = True
        EmployeeNameLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        EmployeeNameLabel.Font = New System.Drawing.Font("Century Schoolbook", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EmployeeNameLabel.Location = New System.Drawing.Point(21, 105)
        EmployeeNameLabel.Name = "EmployeeNameLabel"
        EmployeeNameLabel.Size = New System.Drawing.Size(140, 21)
        EmployeeNameLabel.TabIndex = 2
        EmployeeNameLabel.Text = "Employee Name:"
        '
        'AddressLabel
        '
        AddressLabel.AutoSize = True
        AddressLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        AddressLabel.Font = New System.Drawing.Font("Century Schoolbook", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        AddressLabel.Location = New System.Drawing.Point(25, 163)
        AddressLabel.Name = "AddressLabel"
        AddressLabel.Size = New System.Drawing.Size(79, 21)
        AddressLabel.TabIndex = 4
        AddressLabel.Text = "Address:"
        '
        'ContactNumberLabel
        '
        ContactNumberLabel.AutoSize = True
        ContactNumberLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        ContactNumberLabel.Font = New System.Drawing.Font("Century Schoolbook", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        ContactNumberLabel.Location = New System.Drawing.Point(19, 215)
        ContactNumberLabel.Name = "ContactNumberLabel"
        ContactNumberLabel.Size = New System.Drawing.Size(143, 21)
        ContactNumberLabel.TabIndex = 6
        ContactNumberLabel.Text = "Contact Number:"
        '
        'EmailLabel
        '
        EmailLabel.AutoSize = True
        EmailLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        EmailLabel.Font = New System.Drawing.Font("Century Schoolbook", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EmailLabel.Location = New System.Drawing.Point(22, 275)
        EmailLabel.Name = "EmailLabel"
        EmailLabel.Size = New System.Drawing.Size(59, 21)
        EmailLabel.TabIndex = 8
        EmailLabel.Text = "Email:"
        '
        'BloodTypeLabel
        '
        BloodTypeLabel.AutoSize = True
        BloodTypeLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        BloodTypeLabel.Font = New System.Drawing.Font("Century Schoolbook", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        BloodTypeLabel.Location = New System.Drawing.Point(21, 331)
        BloodTypeLabel.Name = "BloodTypeLabel"
        BloodTypeLabel.Size = New System.Drawing.Size(103, 21)
        BloodTypeLabel.TabIndex = 10
        BloodTypeLabel.Text = "Blood Type:"
        '
        'DepartmentLabel
        '
        DepartmentLabel.AutoSize = True
        DepartmentLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        DepartmentLabel.Font = New System.Drawing.Font("Century Schoolbook", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DepartmentLabel.Location = New System.Drawing.Point(21, 384)
        DepartmentLabel.Name = "DepartmentLabel"
        DepartmentLabel.Size = New System.Drawing.Size(109, 21)
        DepartmentLabel.TabIndex = 12
        DepartmentLabel.Text = "Department:"
        '
        'DesignationLabel
        '
        DesignationLabel.AutoSize = True
        DesignationLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        DesignationLabel.Font = New System.Drawing.Font("Century Schoolbook", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DesignationLabel.Location = New System.Drawing.Point(379, 215)
        DesignationLabel.Name = "DesignationLabel"
        DesignationLabel.Size = New System.Drawing.Size(108, 21)
        DesignationLabel.TabIndex = 14
        DesignationLabel.Text = "Designation:"
        '
        'PositionLabel
        '
        PositionLabel.AutoSize = True
        PositionLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        PositionLabel.Font = New System.Drawing.Font("Century Schoolbook", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        PositionLabel.Location = New System.Drawing.Point(379, 270)
        PositionLabel.Name = "PositionLabel"
        PositionLabel.Size = New System.Drawing.Size(78, 21)
        PositionLabel.TabIndex = 16
        PositionLabel.Text = "Position:"
        AddHandler PositionLabel.Click, AddressOf Me.PositionLabel_Click
        '
        'DateofOriginLabel
        '
        DateofOriginLabel.AutoSize = True
        DateofOriginLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        DateofOriginLabel.Font = New System.Drawing.Font("Century Schoolbook", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DateofOriginLabel.Location = New System.Drawing.Point(381, 327)
        DateofOriginLabel.Name = "DateofOriginLabel"
        DateofOriginLabel.Size = New System.Drawing.Size(121, 21)
        DateofOriginLabel.TabIndex = 18
        DateofOriginLabel.Text = "Dateof Origin:"
        '
        'BasicLabel
        '
        BasicLabel.AutoSize = True
        BasicLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        BasicLabel.Font = New System.Drawing.Font("Century Schoolbook", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        BasicLabel.Location = New System.Drawing.Point(379, 382)
        BasicLabel.Name = "BasicLabel"
        BasicLabel.Size = New System.Drawing.Size(111, 21)
        BasicLabel.TabIndex = 20
        BasicLabel.Text = "Basic Salary:"
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox1.Controls.Add(Me.Button3)
        Me.GroupBox1.Controls.Add(BasicLabel)
        Me.GroupBox1.Controls.Add(Me.BasicTextBox)
        Me.GroupBox1.Controls.Add(DateofOriginLabel)
        Me.GroupBox1.Controls.Add(Me.DateofOriginDateTimePicker)
        Me.GroupBox1.Controls.Add(PositionLabel)
        Me.GroupBox1.Controls.Add(Me.PositionComboBox)
        Me.GroupBox1.Controls.Add(DesignationLabel)
        Me.GroupBox1.Controls.Add(Me.DesignationComboBox)
        Me.GroupBox1.Controls.Add(DepartmentLabel)
        Me.GroupBox1.Controls.Add(Me.DepartmentComboBox)
        Me.GroupBox1.Controls.Add(BloodTypeLabel)
        Me.GroupBox1.Controls.Add(Me.BloodTypeComboBox)
        Me.GroupBox1.Controls.Add(EmailLabel)
        Me.GroupBox1.Controls.Add(Me.EmailTextBox)
        Me.GroupBox1.Controls.Add(ContactNumberLabel)
        Me.GroupBox1.Controls.Add(Me.ContactNumberTextBox)
        Me.GroupBox1.Controls.Add(AddressLabel)
        Me.GroupBox1.Controls.Add(Me.AddressTextBox)
        Me.GroupBox1.Controls.Add(EmployeeNameLabel)
        Me.GroupBox1.Controls.Add(Me.EmployeeNameTextBox)
        Me.GroupBox1.Controls.Add(PlantIDLabel)
        Me.GroupBox1.Controls.Add(Me.PlantIDTextBox)
        Me.GroupBox1.Location = New System.Drawing.Point(111, 61)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(729, 425)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        '
        'Button3
        '
        Me.Button3.BackgroundImage = CType(resources.GetObject("Button3.BackgroundImage"), System.Drawing.Image)
        Me.Button3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.Button3.Font = New System.Drawing.Font("Century Schoolbook", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button3.Location = New System.Drawing.Point(439, 19)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(253, 165)
        Me.Button3.TabIndex = 232
        Me.Button3.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Button3.UseVisualStyleBackColor = True
        '
        'BasicTextBox
        '
        Me.BasicTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.GenPayFinalBindingSource, "Basic", True))
        Me.BasicTextBox.Font = New System.Drawing.Font("Bookman Old Style", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BasicTextBox.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.BasicTextBox.Location = New System.Drawing.Point(538, 382)
        Me.BasicTextBox.Name = "BasicTextBox"
        Me.BasicTextBox.Size = New System.Drawing.Size(182, 23)
        Me.BasicTextBox.TabIndex = 21
        '
        'GenPayFinalBindingSource
        '
        Me.GenPayFinalBindingSource.DataMember = "GenPayFinal"
        Me.GenPayFinalBindingSource.DataSource = Me.GenerallPayrollDataSet
        '
        'GenerallPayrollDataSet
        '
        Me.GenerallPayrollDataSet.DataSetName = "GenerallPayrollDataSet"
        Me.GenerallPayrollDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'DateofOriginDateTimePicker
        '
        Me.DateofOriginDateTimePicker.DataBindings.Add(New System.Windows.Forms.Binding("Value", Me.GenPayFinalBindingSource, "DateofOrigin", True))
        Me.DateofOriginDateTimePicker.Font = New System.Drawing.Font("Bookman Old Style", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DateofOriginDateTimePicker.Location = New System.Drawing.Point(538, 325)
        Me.DateofOriginDateTimePicker.Name = "DateofOriginDateTimePicker"
        Me.DateofOriginDateTimePicker.Size = New System.Drawing.Size(182, 23)
        Me.DateofOriginDateTimePicker.TabIndex = 19
        '
        'PositionComboBox
        '
        Me.PositionComboBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.GenPayFinalBindingSource, "Position", True))
        Me.PositionComboBox.Font = New System.Drawing.Font("Bookman Old Style", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PositionComboBox.FormattingEnabled = True
        Me.PositionComboBox.Items.AddRange(New Object() {"TEMPORARY FACULTY", "ADMINISTRATIVE & SUPPORT STAFF", "CONTRUCTUAL INSTRUCTORS", "CONTRUCTUAL NON-TEACHING STAFF", "ASSOCIATE PROFESSOR IV", "ASSOCIATE PROFESSOR II", "ASSOCIATE PROFESSOR I", "ASSISTANT PROFESSOR I", "ASSISTANT PROFESSOR IV", "ASSISTANT PROFESSOR III", "ASSISTANT PROFESSOR II", "ASSISTANT PROFESSOR I", "INSTRUCTOR I", "INSTRUCTOR II", "INSTRUCTOR III"})
        Me.PositionComboBox.Location = New System.Drawing.Point(538, 265)
        Me.PositionComboBox.Name = "PositionComboBox"
        Me.PositionComboBox.Size = New System.Drawing.Size(182, 26)
        Me.PositionComboBox.TabIndex = 17
        '
        'DesignationComboBox
        '
        Me.DesignationComboBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.GenPayFinalBindingSource, "Designation", True))
        Me.DesignationComboBox.Font = New System.Drawing.Font("Bookman Old Style", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DesignationComboBox.FormattingEnabled = True
        Me.DesignationComboBox.Items.AddRange(New Object() {"Registered Nurse", "Computer Engineer", "Hardware Engineer", "Web Applications Developer", "IT Analyst", "Financial Analyst", "Chemical Engineer", "Computer Engineer", "Guidance Counselor", "Mathematics Teacher", "Physics Teacher", "Research Assistant", "Political Science Teacher", "IT Teacher", "Science Teacher", "Automotive Teacher", "Filipino Teacher", "Graphic Designer", "Clerk/Encoder", "Architect", "Utility", "Truck Driver", "Human Resources Assistant", "Training Specialist"})
        Me.DesignationComboBox.Location = New System.Drawing.Point(538, 210)
        Me.DesignationComboBox.Name = "DesignationComboBox"
        Me.DesignationComboBox.Size = New System.Drawing.Size(182, 26)
        Me.DesignationComboBox.TabIndex = 15
        '
        'DepartmentComboBox
        '
        Me.DepartmentComboBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.GenPayFinalBindingSource, "Department", True))
        Me.DepartmentComboBox.Font = New System.Drawing.Font("Bookman Old Style", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DepartmentComboBox.FormattingEnabled = True
        Me.DepartmentComboBox.Items.AddRange(New Object() {"CEBM", "CECST", "ADMIN"})
        Me.DepartmentComboBox.Location = New System.Drawing.Point(178, 379)
        Me.DepartmentComboBox.Name = "DepartmentComboBox"
        Me.DepartmentComboBox.Size = New System.Drawing.Size(182, 26)
        Me.DepartmentComboBox.TabIndex = 13
        '
        'BloodTypeComboBox
        '
        Me.BloodTypeComboBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.GenPayFinalBindingSource, "BloodType", True))
        Me.BloodTypeComboBox.Font = New System.Drawing.Font("Bookman Old Style", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BloodTypeComboBox.FormattingEnabled = True
        Me.BloodTypeComboBox.Items.AddRange(New Object() {"A+", "A-", "B+", "B-", "O+", "O-", "AB+", "AB-"})
        Me.BloodTypeComboBox.Location = New System.Drawing.Point(178, 326)
        Me.BloodTypeComboBox.Name = "BloodTypeComboBox"
        Me.BloodTypeComboBox.Size = New System.Drawing.Size(182, 26)
        Me.BloodTypeComboBox.TabIndex = 11
        '
        'EmailTextBox
        '
        Me.EmailTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.GenPayFinalBindingSource, "Email", True))
        Me.EmailTextBox.Font = New System.Drawing.Font("Bookman Old Style", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.EmailTextBox.Location = New System.Drawing.Point(178, 270)
        Me.EmailTextBox.Name = "EmailTextBox"
        Me.EmailTextBox.Size = New System.Drawing.Size(182, 23)
        Me.EmailTextBox.TabIndex = 9
        '
        'ContactNumberTextBox
        '
        Me.ContactNumberTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.GenPayFinalBindingSource, "ContactNumber", True))
        Me.ContactNumberTextBox.Font = New System.Drawing.Font("Bookman Old Style", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ContactNumberTextBox.Location = New System.Drawing.Point(178, 213)
        Me.ContactNumberTextBox.Name = "ContactNumberTextBox"
        Me.ContactNumberTextBox.Size = New System.Drawing.Size(182, 23)
        Me.ContactNumberTextBox.TabIndex = 7
        '
        'AddressTextBox
        '
        Me.AddressTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.GenPayFinalBindingSource, "Address", True))
        Me.AddressTextBox.Font = New System.Drawing.Font("Bookman Old Style", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AddressTextBox.Location = New System.Drawing.Point(178, 161)
        Me.AddressTextBox.Name = "AddressTextBox"
        Me.AddressTextBox.Size = New System.Drawing.Size(182, 23)
        Me.AddressTextBox.TabIndex = 5
        '
        'EmployeeNameTextBox
        '
        Me.EmployeeNameTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.GenPayFinalBindingSource, "EmployeeName", True))
        Me.EmployeeNameTextBox.Font = New System.Drawing.Font("Bookman Old Style", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.EmployeeNameTextBox.Location = New System.Drawing.Point(178, 103)
        Me.EmployeeNameTextBox.Name = "EmployeeNameTextBox"
        Me.EmployeeNameTextBox.Size = New System.Drawing.Size(182, 23)
        Me.EmployeeNameTextBox.TabIndex = 3
        '
        'PlantIDTextBox
        '
        Me.PlantIDTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.GenPayFinalBindingSource, "PlantID", True))
        Me.PlantIDTextBox.Font = New System.Drawing.Font("Bookman Old Style", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PlantIDTextBox.Location = New System.Drawing.Point(178, 41)
        Me.PlantIDTextBox.Name = "PlantIDTextBox"
        Me.PlantIDTextBox.Size = New System.Drawing.Size(182, 23)
        Me.PlantIDTextBox.TabIndex = 1
        '
        'GenPayFinalTableAdapter
        '
        Me.GenPayFinalTableAdapter.ClearBeforeFill = True
        '
        'TableAdapterManager
        '
        Me.TableAdapterManager.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager.GenPayFinalTableAdapter = Me.GenPayFinalTableAdapter
        Me.TableAdapterManager.logininfoTableAdapter = Nothing
        Me.TableAdapterManager.staffTableAdapter = Nothing
        Me.TableAdapterManager.UpdateOrder = sdssuHOLLISTICPayrollsystem.GenerallPayrollDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        '
        'Button4
        '
        Me.Button4.Font = New System.Drawing.Font("Century Schoolbook", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button4.Image = CType(resources.GetObject("Button4.Image"), System.Drawing.Image)
        Me.Button4.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button4.Location = New System.Drawing.Point(164, 496)
        Me.Button4.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(108, 43)
        Me.Button4.TabIndex = 73
        Me.Button4.Text = "&Previous"
        Me.Button4.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Button4.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Font = New System.Drawing.Font("Century Schoolbook", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.Image = CType(resources.GetObject("Button1.Image"), System.Drawing.Image)
        Me.Button1.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Button1.Location = New System.Drawing.Point(292, 496)
        Me.Button1.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(92, 43)
        Me.Button1.TabIndex = 72
        Me.Button1.Text = "  &Next"
        Me.Button1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button1.UseVisualStyleBackColor = True
        '
        'btnLogin
        '
        Me.btnLogin.Font = New System.Drawing.Font("Century Schoolbook", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnLogin.Image = CType(resources.GetObject("btnLogin.Image"), System.Drawing.Image)
        Me.btnLogin.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnLogin.Location = New System.Drawing.Point(404, 496)
        Me.btnLogin.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btnLogin.Name = "btnLogin"
        Me.btnLogin.Size = New System.Drawing.Size(99, 43)
        Me.btnLogin.TabIndex = 71
        Me.btnLogin.Text = "&Add New"
        Me.btnLogin.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnLogin.UseVisualStyleBackColor = True
        '
        'Button9
        '
        Me.Button9.Font = New System.Drawing.Font("Palatino Linotype", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button9.Image = CType(resources.GetObject("Button9.Image"), System.Drawing.Image)
        Me.Button9.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button9.Location = New System.Drawing.Point(752, 496)
        Me.Button9.Name = "Button9"
        Me.Button9.Size = New System.Drawing.Size(117, 43)
        Me.Button9.TabIndex = 231
        Me.Button9.Text = "         &View Data"
        Me.Button9.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Button9.UseVisualStyleBackColor = True
        '
        'save
        '
        Me.save.Font = New System.Drawing.Font("Century Schoolbook", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.save.Image = CType(resources.GetObject("save.Image"), System.Drawing.Image)
        Me.save.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.save.Location = New System.Drawing.Point(514, 496)
        Me.save.Name = "save"
        Me.save.Size = New System.Drawing.Size(99, 43)
        Me.save.TabIndex = 229
        Me.save.Text = "    &Save"
        Me.save.UseVisualStyleBackColor = True
        '
        'btnDeleteJHS
        '
        Me.btnDeleteJHS.Font = New System.Drawing.Font("Century Schoolbook", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDeleteJHS.Image = CType(resources.GetObject("btnDeleteJHS.Image"), System.Drawing.Image)
        Me.btnDeleteJHS.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnDeleteJHS.Location = New System.Drawing.Point(630, 496)
        Me.btnDeleteJHS.Name = "btnDeleteJHS"
        Me.btnDeleteJHS.Size = New System.Drawing.Size(99, 43)
        Me.btnDeleteJHS.TabIndex = 230
        Me.btnDeleteJHS.Text = "      &Remove"
        Me.btnDeleteJHS.UseVisualStyleBackColor = True
        '
        'LinkLabel1
        '
        Me.LinkLabel1.AutoSize = True
        Me.LinkLabel1.BackColor = System.Drawing.Color.Transparent
        Me.LinkLabel1.Font = New System.Drawing.Font("Century Schoolbook", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LinkLabel1.LinkColor = System.Drawing.Color.Black
        Me.LinkLabel1.Location = New System.Drawing.Point(394, 35)
        Me.LinkLabel1.Name = "LinkLabel1"
        Me.LinkLabel1.Size = New System.Drawing.Size(174, 23)
        Me.LinkLabel1.TabIndex = 232
        Me.LinkLabel1.TabStop = True
        Me.LinkLabel1.Text = "Employee Detail"
        '
        'Button5
        '
        Me.Button5.BackColor = System.Drawing.Color.White
        Me.Button5.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button5.Font = New System.Drawing.Font("Century Schoolbook", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button5.Image = CType(resources.GetObject("Button5.Image"), System.Drawing.Image)
        Me.Button5.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button5.Location = New System.Drawing.Point(41, 498)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(88, 39)
        Me.Button5.TabIndex = 244
        Me.Button5.Text = "&Back"
        Me.Button5.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Button5.UseVisualStyleBackColor = False
        '
        'frmregister
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Window
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(933, 575)
        Me.Controls.Add(Me.Button5)
        Me.Controls.Add(Me.LinkLabel1)
        Me.Controls.Add(Me.Button9)
        Me.Controls.Add(Me.save)
        Me.Controls.Add(Me.btnDeleteJHS)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.btnLogin)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.GroupBox1)
        Me.Cursor = System.Windows.Forms.Cursors.Hand
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Name = "frmregister"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Register"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.GenPayFinalBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.GenerallPayrollDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents GenerallPayrollDataSet As sdssuHOLLISTICPayrollsystem.GenerallPayrollDataSet
    Friend WithEvents GenPayFinalBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents GenPayFinalTableAdapter As sdssuHOLLISTICPayrollsystem.GenerallPayrollDataSetTableAdapters.GenPayFinalTableAdapter
    Friend WithEvents TableAdapterManager As sdssuHOLLISTICPayrollsystem.GenerallPayrollDataSetTableAdapters.TableAdapterManager
    Friend WithEvents BasicTextBox As System.Windows.Forms.TextBox
    Friend WithEvents DateofOriginDateTimePicker As System.Windows.Forms.DateTimePicker
    Friend WithEvents PositionComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents DesignationComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents DepartmentComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents BloodTypeComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents EmailTextBox As System.Windows.Forms.TextBox
    Friend WithEvents ContactNumberTextBox As System.Windows.Forms.TextBox
    Friend WithEvents AddressTextBox As System.Windows.Forms.TextBox
    Friend WithEvents EmployeeNameTextBox As System.Windows.Forms.TextBox
    Friend WithEvents PlantIDTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents btnLogin As System.Windows.Forms.Button
    Friend WithEvents Button9 As System.Windows.Forms.Button
    Friend WithEvents save As System.Windows.Forms.Button
    Friend WithEvents btnDeleteJHS As System.Windows.Forms.Button
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents LinkLabel1 As System.Windows.Forms.LinkLabel
    Friend WithEvents Button5 As System.Windows.Forms.Button
End Class
