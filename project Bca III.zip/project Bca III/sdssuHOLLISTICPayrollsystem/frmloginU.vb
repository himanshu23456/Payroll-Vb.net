﻿Public Class frmloginU

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click

        If txtUsername.Text = "" Or txtPassword.Text = "" Then
            MsgBox("please Enter the Username and Password")
        ElseIf txtUsername.Text = "Rajeev" And txtPassword.Text = "2003" Then
            Dim obj = New frmmainU
            obj.Show()
            Me.Hide()
        Else
            MsgBox("Enter correct UserId And Password", MsgBoxStyle.Information, "LOGIN")
        End If
    End Sub

    Private Sub Button7_Click(sender As Object, e As EventArgs) Handles Button7.Click
        txtUsername.Text = ""
        txtPassword.Text = ""
    End Sub

    Private Sub CheckBox2_CheckedChanged(sender As Object, e As EventArgs) Handles ShowPassword.CheckedChanged
        If ShowPassword.Checked = True Then
            txtPassword.PasswordChar = ""
        Else
            txtPassword.PasswordChar = "*"
        End If
    End Sub

    Private Sub ForgetPassword_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles ForgetPassword.LinkClicked
        MsgBox("Your ID is admin And Password is admin", MsgBoxStyle.Information, "Forget Password")
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If MsgBox("Do you want to switch user?", vbYesNo + vbQuestion) = vbYes Then
            Me.Hide()
            txtUsername.Clear()
            txtPassword.Clear()
            Frmchoose.Show()
        End If
    End Sub

    Private Sub frmloginU_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class