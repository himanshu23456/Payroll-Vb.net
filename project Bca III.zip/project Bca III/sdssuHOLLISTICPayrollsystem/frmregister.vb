﻿Public Class frmregister

    Private Sub GenPayFinalBindingNavigatorSaveItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Me.Validate()
        Me.GenPayFinalBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.GenerallPayrollDataSet)

    End Sub

    Private Sub frmregister_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'GenerallPayrollDataSet.GenPayFinal' table. You can move, or remove it, as needed.
        Me.GenPayFinalTableAdapter.Fill(Me.GenerallPayrollDataSet.GenPayFinal)
        'TODO: This line of code loads data into the 'GenerallPayrollDataSet.GenPayFinal' table. You can move, or remove it, as needed.
        Me.GenPayFinalTableAdapter.Fill(Me.GenerallPayrollDataSet.GenPayFinal)

    End Sub

    Private Sub GenPayFinalBindingNavigatorSaveItem_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Me.Validate()
        Me.GenPayFinalBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.GenerallPayrollDataSet)

    End Sub
    


    Private Sub Email_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles EmailTextBox.Validating
        Dim rEMail As New System.Text.RegularExpressions.Regex("^[a-zA-Z][\w\.-]{2,28}[a-zA-Z0-9]@[a-zA-Z0-9][\w\.-]*[a-zA-Z0-9]\.[a-zA-Z][a-zA-Z\.]*[a-zA-Z]$")
        If EmailTextBox.Text.Length > 0 Then
            If Not rEMail.IsMatch(EmailTextBox.Text) Then
                MessageBox.Show("invalid email address", "Error", MessageBoxButtons.OK, MessageBoxIcon.[Error])
                EmailTextBox.SelectAll()
                e.Cancel = True
            End If
        End If
    End Sub

  

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs)

    End Sub

    Private Sub txtReceipt1_TextChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub PrintDocument1_PrintPage(sender As Object, e As Printing.PrintPageEventArgs)

    End Sub

    Private Sub PositionLabel_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub btnRemov_Click(sender As Object, e As EventArgs) Handles btnDeleteJHS.Click

        Try
            If PlantIDTextBox.Text = "" Then
                MessageBox.Show("Please select employee id", "Entry", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                Exit Sub
            End If
            If PlantIDTextBox.Text.Count > 0 Then
                If MessageBox.Show("Do you really want to delete the record?" & vbCrLf & "You can not restore the record" & vbCrLf & "It will delete record permanently" & vbCrLf & "related to selected employee", "Warning!!!", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) = Windows.Forms.DialogResult.Yes Then
                    GenPayFinalBindingSource.RemoveCurrent()
                    Me.TableAdapterManager.UpdateAll(Me.GenerallPayrollDataSet)
                End If
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        GenPayFinalBindingSource.MovePrevious()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        GenPayFinalBindingSource.MoveNext()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles btnLogin.Click


        If Len(Trim(PlantIDTextBox.Text)) = 0 Then
            MessageBox.Show("Please enter employee Plant ID", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            PlantIDTextBox.Focus()
            Exit Sub
        End If

        If Len(Trim(EmployeeNameTextBox.Text)) = 0 Then
            MessageBox.Show("Please enter employee name", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            EmployeeNameTextBox.Focus()
            Exit Sub
        End If

        If Len(Trim(AddressTextBox.Text)) = 0 Then
            MessageBox.Show("Please enter employee Address", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            AddressTextBox.Focus()
            Exit Sub
        End If

        If Len(Trim(ContactNumberTextBox.Text)) = 0 Then
            MessageBox.Show("Please enter employee Contact Number", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            ContactNumberTextBox.Focus()
            Exit Sub
        End If

        If Len(Trim(EmailTextBox.Text)) = 0 Then
            MessageBox.Show("Please enter employee Email", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            EmailTextBox.Focus()
            Exit Sub
        End If

        If Len(Trim(BloodTypeComboBox.Text)) = 0 Then
            MessageBox.Show("Please enter employee Blood Type", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            BloodTypeComboBox.Focus()
            Exit Sub
        End If

        If Len(Trim(DepartmentComboBox.Text)) = 0 Then
            MessageBox.Show("Please enter employee Department", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            DepartmentComboBox.Focus()
            Exit Sub
        End If

        If Len(Trim(DesignationComboBox.Text)) = 0 Then
            MessageBox.Show("Please enter employee Designation", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            DesignationComboBox.Focus()
            Exit Sub
        End If

        If Len(Trim(PositionComboBox.Text)) = 0 Then
            MessageBox.Show("Please enter employee Position", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            PositionComboBox.Focus()
            Exit Sub
        End If

        If Len(Trim(DateofOriginDateTimePicker.Text)) = 0 Then
            MessageBox.Show("Please enter employee Date of Origin", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            DateofOriginDateTimePicker.Focus()
            Exit Sub
        End If

        If Len(Trim(BasicTextBox.Text)) = 0 Then
            MessageBox.Show("Please enter employee Basic Salary", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            BasicTextBox.Focus()
            Exit Sub
        End If

        Try
            If MsgBox("Do you want to add new employee?", vbYesNo + vbQuestion) = vbYes Then
                GenPayFinalBindingSource.AddNew()
                Me.TableAdapterManager.UpdateAll(Me.GenerallPayrollDataSet)
                MessageBox.Show("You can now input...")
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

    End Sub

    Private Sub btnLogin_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub save_Click(sender As Object, e As EventArgs) Handles save.Click

        If Len(Trim(PlantIDTextBox.Text)) = 0 Then
            MessageBox.Show("Please enter employee Plant ID", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            PlantIDTextBox.Focus()
            Exit Sub
        End If

        If Len(Trim(EmployeeNameTextBox.Text)) = 0 Then
            MessageBox.Show("Please enter employee name", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            EmployeeNameTextBox.Focus()
            Exit Sub
        End If

        If Len(Trim(AddressTextBox.Text)) = 0 Then
            MessageBox.Show("Please enter employee Address", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            AddressTextBox.Focus()
            Exit Sub
        End If

        If Len(Trim(ContactNumberTextBox.Text)) = 0 Then
            MessageBox.Show("Please enter employee Contact Number", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            ContactNumberTextBox.Focus()
            Exit Sub
        End If

        If Len(Trim(EmailTextBox.Text)) = 0 Then
            MessageBox.Show("Please enter employee Email", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            EmailTextBox.Focus()
            Exit Sub
        End If

        If Len(Trim(BloodTypeComboBox.Text)) = 0 Then
            MessageBox.Show("Please enter employee Blood Type", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            BloodTypeComboBox.Focus()
            Exit Sub
        End If

        If Len(Trim(DepartmentComboBox.Text)) = 0 Then
            MessageBox.Show("Please enter employee Department", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            DepartmentComboBox.Focus()
            Exit Sub
        End If

        If Len(Trim(DesignationComboBox.Text)) = 0 Then
            MessageBox.Show("Please enter employee Designation", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            DesignationComboBox.Focus()
            Exit Sub
        End If

        If Len(Trim(PositionComboBox.Text)) = 0 Then
            MessageBox.Show("Please enter employee Position", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            PositionComboBox.Focus()
            Exit Sub
        End If

        If Len(Trim(DateofOriginDateTimePicker.Text)) = 0 Then
            MessageBox.Show("Please enter employee Date of Origin", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            DateofOriginDateTimePicker.Focus()
            Exit Sub
        End If

        If Len(Trim(BasicTextBox.Text)) = 0 Then
            MessageBox.Show("Please enter employee Basic Salary", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            BasicTextBox.Focus()
            Exit Sub
        End If

        Try
            Me.Validate()
            Me.GenPayFinalBindingSource.EndEdit()
            Me.TableAdapterManager.UpdateAll(Me.GenerallPayrollDataSet)
            MessageBox.Show("Successfully Added")
            EmployeeNameTextBox.Focus()
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Button9_Click(sender As Object, e As EventArgs) Handles Button9.Click
        Payview.Show()

    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click

        Me.TableAdapterManager.UpdateAll(Me.GenerallPayrollDataSet)
        Me.Close()

    End Sub

End Class