﻿
Public Class frmloginA

  
    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        If MsgBox("Do you want to switch user?", vbYesNo + vbQuestion) = vbYes Then
            Me.Hide()
            txtUsername.Clear()
            txtPassword.Clear()
            Frmchoose.Show()
        End If
    End Sub

    Private Sub txtUsername_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub CheckBox1_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox1.CheckedChanged
        If CheckBox1.Checked = True Then
            txtPassword.PasswordChar = ""
        Else
            txtPassword.PasswordChar = "•"
        End If
    End Sub

    Private Sub Button7_Click(sender As Object, e As EventArgs) Handles Button7.Click
        txtUsername.Text = ""
        txtPassword.Text = ""

    End Sub

    Private Sub ForgetPassword_LinkClicked_1(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles ForgetPassword.LinkClicked
        MsgBox("Your ID is admin And Password is admin", MsgBoxStyle.Information, "Forget Password")
    End Sub

    Private Sub PictureBox4_Click(sender As Object, e As EventArgs) Handles PictureBox4.Click
        MsgBox("These is UserName")
    End Sub

    Private Sub PictureBox3_Click(sender As Object, e As EventArgs) Handles PictureBox3.Click
        MsgBox("These is Password")
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click

        If txtUsername.Text = "" Or txtPassword.Text = "" Then
            MsgBox("please Enter the Username and Password")
        ElseIf txtUsername.Text = "Rajeev" And txtPassword.Text = "Sahu" Then
            Dim obj = New frmMainA
            obj.Show()
            Me.Hide()
        Else
            MsgBox("Enter correct UserId And Password", MsgBoxStyle.Information, "LOGIN")
        End If
    End Sub

    Private Sub frmloginA_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class