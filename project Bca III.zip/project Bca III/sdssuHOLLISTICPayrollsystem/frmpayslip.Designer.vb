﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmpayslip
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim PlantIDLabel As System.Windows.Forms.Label
        Dim EmployeeNameLabel As System.Windows.Forms.Label
        Dim BasicLabel As System.Windows.Forms.Label
        Dim PERALabel As System.Windows.Forms.Label
        Dim GrossAmountLabel As System.Windows.Forms.Label
        Dim WtaxLabel As System.Windows.Forms.Label
        Dim GSISPremiumLabel As System.Windows.Forms.Label
        Dim GSISSalaryLoanLabel As System.Windows.Forms.Label
        Dim GSISELLabel As System.Windows.Forms.Label
        Dim GSISEMRGLLabel As System.Windows.Forms.Label
        Dim GSISPLLabel As System.Windows.Forms.Label
        Dim PagIbigPremLabel As System.Windows.Forms.Label
        Dim PagIbigMLLabel As System.Windows.Forms.Label
        Dim PagIbig2Label As System.Windows.Forms.Label
        Dim PhilHealthPremiunLabel As System.Windows.Forms.Label
        Dim LEAPLabel As System.Windows.Forms.Label
        Dim IGPLabel As System.Windows.Forms.Label
        Dim FacultyUnionLabel As System.Windows.Forms.Label
        Dim RefundDisallowLabel As System.Windows.Forms.Label
        Dim TuitionLabel As System.Windows.Forms.Label
        Dim LBPPaymentLabel As System.Windows.Forms.Label
        Dim CitySavingsLabel As System.Windows.Forms.Label
        Dim TotalDeductionLabel As System.Windows.Forms.Label
        Dim NetAmountLabel As System.Windows.Forms.Label
        Dim NoLabel As System.Windows.Forms.Label
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmpayslip))
        Me.GenerallPayrollDataSet = New sdssuHOLLISTICPayrollsystem.GenerallPayrollDataSet()
        Me.GenPayFinalBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.GenPayFinalTableAdapter = New sdssuHOLLISTICPayrollsystem.GenerallPayrollDataSetTableAdapters.GenPayFinalTableAdapter()
        Me.TableAdapterManager = New sdssuHOLLISTICPayrollsystem.GenerallPayrollDataSetTableAdapters.TableAdapterManager()
        Me.PlantIDTextBox = New System.Windows.Forms.TextBox()
        Me.EmployeeNameTextBox = New System.Windows.Forms.TextBox()
        Me.BasicTextBox = New System.Windows.Forms.TextBox()
        Me.PERATextBox = New System.Windows.Forms.TextBox()
        Me.GrossAmountTextBox = New System.Windows.Forms.TextBox()
        Me.WtaxTextBox = New System.Windows.Forms.TextBox()
        Me.GSISPremiumTextBox = New System.Windows.Forms.TextBox()
        Me.GSISSalaryLoanTextBox = New System.Windows.Forms.TextBox()
        Me.GSISELTextBox = New System.Windows.Forms.TextBox()
        Me.GSISEMRGLTextBox = New System.Windows.Forms.TextBox()
        Me.GSISPLTextBox = New System.Windows.Forms.TextBox()
        Me.PagIbigPremTextBox = New System.Windows.Forms.TextBox()
        Me.PagIbigMLTextBox = New System.Windows.Forms.TextBox()
        Me.PagIbig2TextBox = New System.Windows.Forms.TextBox()
        Me.PhilHealthPremiunTextBox = New System.Windows.Forms.TextBox()
        Me.LEAPTextBox = New System.Windows.Forms.TextBox()
        Me.IGPTextBox = New System.Windows.Forms.TextBox()
        Me.FacultyUnionTextBox = New System.Windows.Forms.TextBox()
        Me.RefundDisallowTextBox = New System.Windows.Forms.TextBox()
        Me.TuitionTextBox = New System.Windows.Forms.TextBox()
        Me.LBPPaymentTextBox = New System.Windows.Forms.TextBox()
        Me.CitySavingsTextBox = New System.Windows.Forms.TextBox()
        Me.TotalDeductionTextBox = New System.Windows.Forms.TextBox()
        Me.NetAmountTextBox = New System.Windows.Forms.TextBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.NoTextBox = New System.Windows.Forms.TextBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.GroupBox6 = New System.Windows.Forms.GroupBox()
        Me.PrintDocument1 = New System.Drawing.Printing.PrintDocument()
        Me.PrintPreviewDialog1 = New System.Windows.Forms.PrintPreviewDialog()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.save = New System.Windows.Forms.Button()
        Me.btnDeleteJHS = New System.Windows.Forms.Button()
        Me.Button10 = New System.Windows.Forms.Button()
        Me.btnLogin = New System.Windows.Forms.Button()
        Me.Button11 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.LinkLabel1 = New System.Windows.Forms.LinkLabel()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        PlantIDLabel = New System.Windows.Forms.Label()
        EmployeeNameLabel = New System.Windows.Forms.Label()
        BasicLabel = New System.Windows.Forms.Label()
        PERALabel = New System.Windows.Forms.Label()
        GrossAmountLabel = New System.Windows.Forms.Label()
        WtaxLabel = New System.Windows.Forms.Label()
        GSISPremiumLabel = New System.Windows.Forms.Label()
        GSISSalaryLoanLabel = New System.Windows.Forms.Label()
        GSISELLabel = New System.Windows.Forms.Label()
        GSISEMRGLLabel = New System.Windows.Forms.Label()
        GSISPLLabel = New System.Windows.Forms.Label()
        PagIbigPremLabel = New System.Windows.Forms.Label()
        PagIbigMLLabel = New System.Windows.Forms.Label()
        PagIbig2Label = New System.Windows.Forms.Label()
        PhilHealthPremiunLabel = New System.Windows.Forms.Label()
        LEAPLabel = New System.Windows.Forms.Label()
        IGPLabel = New System.Windows.Forms.Label()
        FacultyUnionLabel = New System.Windows.Forms.Label()
        RefundDisallowLabel = New System.Windows.Forms.Label()
        TuitionLabel = New System.Windows.Forms.Label()
        LBPPaymentLabel = New System.Windows.Forms.Label()
        CitySavingsLabel = New System.Windows.Forms.Label()
        TotalDeductionLabel = New System.Windows.Forms.Label()
        NetAmountLabel = New System.Windows.Forms.Label()
        NoLabel = New System.Windows.Forms.Label()
        CType(Me.GenerallPayrollDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.GenPayFinalBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.GroupBox5.SuspendLayout()
        Me.GroupBox6.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'PlantIDLabel
        '
        PlantIDLabel.AutoSize = True
        PlantIDLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        PlantIDLabel.Font = New System.Drawing.Font("Century Schoolbook", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        PlantIDLabel.Location = New System.Drawing.Point(7, 23)
        PlantIDLabel.Name = "PlantIDLabel"
        PlantIDLabel.Size = New System.Drawing.Size(80, 21)
        PlantIDLabel.TabIndex = 1
        PlantIDLabel.Text = "Plant ID:"
        '
        'EmployeeNameLabel
        '
        EmployeeNameLabel.AutoSize = True
        EmployeeNameLabel.BackColor = System.Drawing.Color.Transparent
        EmployeeNameLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        EmployeeNameLabel.Font = New System.Drawing.Font("Century Schoolbook", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EmployeeNameLabel.ForeColor = System.Drawing.Color.Black
        EmployeeNameLabel.Location = New System.Drawing.Point(7, 64)
        EmployeeNameLabel.Name = "EmployeeNameLabel"
        EmployeeNameLabel.Size = New System.Drawing.Size(148, 21)
        EmployeeNameLabel.TabIndex = 2
        EmployeeNameLabel.Text = "*Employee Name:"
        '
        'BasicLabel
        '
        BasicLabel.AutoSize = True
        BasicLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        BasicLabel.Font = New System.Drawing.Font("Century Schoolbook", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        BasicLabel.Location = New System.Drawing.Point(20, 23)
        BasicLabel.Name = "BasicLabel"
        BasicLabel.Size = New System.Drawing.Size(57, 21)
        BasicLabel.TabIndex = 6
        BasicLabel.Text = "Basic:"
        '
        'PERALabel
        '
        PERALabel.AutoSize = True
        PERALabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        PERALabel.Font = New System.Drawing.Font("Century Schoolbook", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        PERALabel.Location = New System.Drawing.Point(20, 55)
        PERALabel.Name = "PERALabel"
        PERALabel.Size = New System.Drawing.Size(60, 21)
        PERALabel.TabIndex = 8
        PERALabel.Text = "PERA:"
        '
        'GrossAmountLabel
        '
        GrossAmountLabel.AutoSize = True
        GrossAmountLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        GrossAmountLabel.Font = New System.Drawing.Font("Century Schoolbook", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        GrossAmountLabel.ForeColor = System.Drawing.Color.Red
        GrossAmountLabel.Location = New System.Drawing.Point(13, 22)
        GrossAmountLabel.Name = "GrossAmountLabel"
        GrossAmountLabel.Size = New System.Drawing.Size(133, 21)
        GrossAmountLabel.TabIndex = 10
        GrossAmountLabel.Text = "Gross Amount:"
        '
        'WtaxLabel
        '
        WtaxLabel.AutoSize = True
        WtaxLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        WtaxLabel.Font = New System.Drawing.Font("Century Schoolbook", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        WtaxLabel.Location = New System.Drawing.Point(16, 37)
        WtaxLabel.Name = "WtaxLabel"
        WtaxLabel.Size = New System.Drawing.Size(58, 21)
        WtaxLabel.TabIndex = 12
        WtaxLabel.Text = "W/tax:"
        '
        'GSISPremiumLabel
        '
        GSISPremiumLabel.AutoSize = True
        GSISPremiumLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        GSISPremiumLabel.Font = New System.Drawing.Font("Century Schoolbook", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        GSISPremiumLabel.Location = New System.Drawing.Point(16, 68)
        GSISPremiumLabel.Name = "GSISPremiumLabel"
        GSISPremiumLabel.Size = New System.Drawing.Size(130, 21)
        GSISPremiumLabel.TabIndex = 14
        GSISPremiumLabel.Text = "GSIS Premium:"
        '
        'GSISSalaryLoanLabel
        '
        GSISSalaryLoanLabel.AutoSize = True
        GSISSalaryLoanLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        GSISSalaryLoanLabel.Font = New System.Drawing.Font("Century Schoolbook", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        GSISSalaryLoanLabel.Location = New System.Drawing.Point(16, 102)
        GSISSalaryLoanLabel.Name = "GSISSalaryLoanLabel"
        GSISSalaryLoanLabel.Size = New System.Drawing.Size(152, 21)
        GSISSalaryLoanLabel.TabIndex = 16
        GSISSalaryLoanLabel.Text = "GSIS Salary Loan:"
        '
        'GSISELLabel
        '
        GSISELLabel.AutoSize = True
        GSISELLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        GSISELLabel.Font = New System.Drawing.Font("Century Schoolbook", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        GSISELLabel.Location = New System.Drawing.Point(19, 142)
        GSISELLabel.Name = "GSISELLabel"
        GSISELLabel.Size = New System.Drawing.Size(81, 21)
        GSISELLabel.TabIndex = 18
        GSISELLabel.Text = "GSIS EL:"
        '
        'GSISEMRGLLabel
        '
        GSISEMRGLLabel.AutoSize = True
        GSISEMRGLLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        GSISEMRGLLabel.Font = New System.Drawing.Font("Century Schoolbook", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        GSISEMRGLLabel.Location = New System.Drawing.Point(19, 178)
        GSISEMRGLLabel.Name = "GSISEMRGLLabel"
        GSISEMRGLLabel.Size = New System.Drawing.Size(117, 21)
        GSISEMRGLLabel.TabIndex = 20
        GSISEMRGLLabel.Text = "GSISEMRGL:"
        '
        'GSISPLLabel
        '
        GSISPLLabel.AutoSize = True
        GSISPLLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        GSISPLLabel.Font = New System.Drawing.Font("Century Schoolbook", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        GSISPLLabel.Location = New System.Drawing.Point(19, 212)
        GSISPLLabel.Name = "GSISPLLabel"
        GSISPLLabel.Size = New System.Drawing.Size(81, 21)
        GSISPLLabel.TabIndex = 22
        GSISPLLabel.Text = "GSIS PL:"
        '
        'PagIbigPremLabel
        '
        PagIbigPremLabel.AutoSize = True
        PagIbigPremLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        PagIbigPremLabel.Font = New System.Drawing.Font("Century Schoolbook", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        PagIbigPremLabel.Location = New System.Drawing.Point(19, 246)
        PagIbigPremLabel.Name = "PagIbigPremLabel"
        PagIbigPremLabel.Size = New System.Drawing.Size(125, 21)
        PagIbigPremLabel.TabIndex = 24
        PagIbigPremLabel.Text = "Pag Ibig Prem:"
        '
        'PagIbigMLLabel
        '
        PagIbigMLLabel.AutoSize = True
        PagIbigMLLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        PagIbigMLLabel.Font = New System.Drawing.Font("Century Schoolbook", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        PagIbigMLLabel.Location = New System.Drawing.Point(19, 278)
        PagIbigMLLabel.Name = "PagIbigMLLabel"
        PagIbigMLLabel.Size = New System.Drawing.Size(109, 21)
        PagIbigMLLabel.TabIndex = 26
        PagIbigMLLabel.Text = "Pag Ibig ML:"
        '
        'PagIbig2Label
        '
        PagIbig2Label.AutoSize = True
        PagIbig2Label.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        PagIbig2Label.Font = New System.Drawing.Font("Century Schoolbook", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        PagIbig2Label.Location = New System.Drawing.Point(19, 312)
        PagIbig2Label.Name = "PagIbig2Label"
        PagIbig2Label.Size = New System.Drawing.Size(88, 21)
        PagIbig2Label.TabIndex = 28
        PagIbig2Label.Text = "Pag Ibig2:"
        '
        'PhilHealthPremiunLabel
        '
        PhilHealthPremiunLabel.AutoSize = True
        PhilHealthPremiunLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        PhilHealthPremiunLabel.Font = New System.Drawing.Font("Century Schoolbook", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        PhilHealthPremiunLabel.Location = New System.Drawing.Point(16, 347)
        PhilHealthPremiunLabel.Name = "PhilHealthPremiunLabel"
        PhilHealthPremiunLabel.Size = New System.Drawing.Size(173, 21)
        PhilHealthPremiunLabel.TabIndex = 30
        PhilHealthPremiunLabel.Text = "Phil Health Premiun:"
        '
        'LEAPLabel
        '
        LEAPLabel.AutoSize = True
        LEAPLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        LEAPLabel.Font = New System.Drawing.Font("Century Schoolbook", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        LEAPLabel.Location = New System.Drawing.Point(24, 381)
        LEAPLabel.Name = "LEAPLabel"
        LEAPLabel.Size = New System.Drawing.Size(59, 21)
        LEAPLabel.TabIndex = 32
        LEAPLabel.Text = "LEAP:"
        '
        'IGPLabel
        '
        IGPLabel.AutoSize = True
        IGPLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        IGPLabel.Font = New System.Drawing.Font("Century Schoolbook", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        IGPLabel.Location = New System.Drawing.Point(368, 212)
        IGPLabel.Name = "IGPLabel"
        IGPLabel.Size = New System.Drawing.Size(46, 21)
        IGPLabel.TabIndex = 34
        IGPLabel.Text = "IGP:"
        '
        'FacultyUnionLabel
        '
        FacultyUnionLabel.AutoSize = True
        FacultyUnionLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        FacultyUnionLabel.Font = New System.Drawing.Font("Century Schoolbook", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        FacultyUnionLabel.Location = New System.Drawing.Point(367, 249)
        FacultyUnionLabel.Name = "FacultyUnionLabel"
        FacultyUnionLabel.Size = New System.Drawing.Size(124, 21)
        FacultyUnionLabel.TabIndex = 36
        FacultyUnionLabel.Text = "Faculty Union:"
        '
        'RefundDisallowLabel
        '
        RefundDisallowLabel.AutoSize = True
        RefundDisallowLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        RefundDisallowLabel.Font = New System.Drawing.Font("Century Schoolbook", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        RefundDisallowLabel.Location = New System.Drawing.Point(367, 278)
        RefundDisallowLabel.Name = "RefundDisallowLabel"
        RefundDisallowLabel.Size = New System.Drawing.Size(143, 21)
        RefundDisallowLabel.TabIndex = 38
        RefundDisallowLabel.Text = "Refund Disallow:"
        '
        'TuitionLabel
        '
        TuitionLabel.AutoSize = True
        TuitionLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        TuitionLabel.Font = New System.Drawing.Font("Century Schoolbook", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        TuitionLabel.Location = New System.Drawing.Point(367, 314)
        TuitionLabel.Name = "TuitionLabel"
        TuitionLabel.Size = New System.Drawing.Size(71, 21)
        TuitionLabel.TabIndex = 40
        TuitionLabel.Text = "Tuition:"
        '
        'LBPPaymentLabel
        '
        LBPPaymentLabel.AutoSize = True
        LBPPaymentLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        LBPPaymentLabel.Font = New System.Drawing.Font("Century Schoolbook", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        LBPPaymentLabel.Location = New System.Drawing.Point(367, 351)
        LBPPaymentLabel.Name = "LBPPaymentLabel"
        LBPPaymentLabel.Size = New System.Drawing.Size(117, 21)
        LBPPaymentLabel.TabIndex = 42
        LBPPaymentLabel.Text = "LBPPayment:"
        '
        'CitySavingsLabel
        '
        CitySavingsLabel.AutoSize = True
        CitySavingsLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        CitySavingsLabel.Font = New System.Drawing.Font("Century Schoolbook", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        CitySavingsLabel.Location = New System.Drawing.Point(367, 386)
        CitySavingsLabel.Name = "CitySavingsLabel"
        CitySavingsLabel.Size = New System.Drawing.Size(111, 21)
        CitySavingsLabel.TabIndex = 44
        CitySavingsLabel.Text = "City Savings:"
        '
        'TotalDeductionLabel
        '
        TotalDeductionLabel.AutoSize = True
        TotalDeductionLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        TotalDeductionLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        TotalDeductionLabel.ForeColor = System.Drawing.Color.Red
        TotalDeductionLabel.Location = New System.Drawing.Point(7, 20)
        TotalDeductionLabel.Name = "TotalDeductionLabel"
        TotalDeductionLabel.Size = New System.Drawing.Size(143, 22)
        TotalDeductionLabel.TabIndex = 46
        TotalDeductionLabel.Text = "Total Deduction:"
        '
        'NetAmountLabel
        '
        NetAmountLabel.AutoSize = True
        NetAmountLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        NetAmountLabel.Font = New System.Drawing.Font("MS Reference Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        NetAmountLabel.ForeColor = System.Drawing.Color.Red
        NetAmountLabel.Location = New System.Drawing.Point(6, 20)
        NetAmountLabel.Name = "NetAmountLabel"
        NetAmountLabel.Size = New System.Drawing.Size(127, 22)
        NetAmountLabel.TabIndex = 48
        NetAmountLabel.Text = "Net Amount:"
        '
        'NoLabel
        '
        NoLabel.AutoSize = True
        NoLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        NoLabel.Font = New System.Drawing.Font("Century Schoolbook", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        NoLabel.Location = New System.Drawing.Point(7, 102)
        NoLabel.Name = "NoLabel"
        NoLabel.Size = New System.Drawing.Size(37, 21)
        NoLabel.TabIndex = 4
        NoLabel.Text = "No:"
        '
        'GenerallPayrollDataSet
        '
        Me.GenerallPayrollDataSet.DataSetName = "GenerallPayrollDataSet"
        Me.GenerallPayrollDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'GenPayFinalBindingSource
        '
        Me.GenPayFinalBindingSource.DataMember = "GenPayFinal"
        Me.GenPayFinalBindingSource.DataSource = Me.GenerallPayrollDataSet
        '
        'GenPayFinalTableAdapter
        '
        Me.GenPayFinalTableAdapter.ClearBeforeFill = True
        '
        'TableAdapterManager
        '
        Me.TableAdapterManager.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager.GenPayFinalTableAdapter = Me.GenPayFinalTableAdapter
        Me.TableAdapterManager.logininfoTableAdapter = Nothing
        Me.TableAdapterManager.staffTableAdapter = Nothing
        Me.TableAdapterManager.UpdateOrder = sdssuHOLLISTICPayrollsystem.GenerallPayrollDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        '
        'PlantIDTextBox
        '
        Me.PlantIDTextBox.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.PlantIDTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.GenPayFinalBindingSource, "PlantID", True))
        Me.PlantIDTextBox.Location = New System.Drawing.Point(161, 21)
        Me.PlantIDTextBox.Name = "PlantIDTextBox"
        Me.PlantIDTextBox.Size = New System.Drawing.Size(152, 22)
        Me.PlantIDTextBox.TabIndex = 2
        '
        'EmployeeNameTextBox
        '
        Me.EmployeeNameTextBox.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.EmployeeNameTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.GenPayFinalBindingSource, "EmployeeName", True))
        Me.EmployeeNameTextBox.Location = New System.Drawing.Point(161, 64)
        Me.EmployeeNameTextBox.Name = "EmployeeNameTextBox"
        Me.EmployeeNameTextBox.Size = New System.Drawing.Size(152, 22)
        Me.EmployeeNameTextBox.TabIndex = 3
        '
        'BasicTextBox
        '
        Me.BasicTextBox.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.BasicTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.GenPayFinalBindingSource, "Basic", True))
        Me.BasicTextBox.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BasicTextBox.Location = New System.Drawing.Point(161, 19)
        Me.BasicTextBox.Name = "BasicTextBox"
        Me.BasicTextBox.Size = New System.Drawing.Size(152, 22)
        Me.BasicTextBox.TabIndex = 7
        '
        'PERATextBox
        '
        Me.PERATextBox.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.PERATextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.GenPayFinalBindingSource, "PERA", True))
        Me.PERATextBox.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PERATextBox.Location = New System.Drawing.Point(161, 54)
        Me.PERATextBox.Name = "PERATextBox"
        Me.PERATextBox.Size = New System.Drawing.Size(152, 22)
        Me.PERATextBox.TabIndex = 9
        '
        'GrossAmountTextBox
        '
        Me.GrossAmountTextBox.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.GrossAmountTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.GenPayFinalBindingSource, "GrossAmount", True))
        Me.GrossAmountTextBox.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GrossAmountTextBox.Location = New System.Drawing.Point(154, 19)
        Me.GrossAmountTextBox.Name = "GrossAmountTextBox"
        Me.GrossAmountTextBox.ReadOnly = True
        Me.GrossAmountTextBox.Size = New System.Drawing.Size(147, 24)
        Me.GrossAmountTextBox.TabIndex = 11
        '
        'WtaxTextBox
        '
        Me.WtaxTextBox.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.WtaxTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.GenPayFinalBindingSource, "Wtax", True))
        Me.WtaxTextBox.Font = New System.Drawing.Font("Century Schoolbook", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.WtaxTextBox.ForeColor = System.Drawing.Color.Black
        Me.WtaxTextBox.Location = New System.Drawing.Point(194, 32)
        Me.WtaxTextBox.Name = "WtaxTextBox"
        Me.WtaxTextBox.Size = New System.Drawing.Size(154, 23)
        Me.WtaxTextBox.TabIndex = 13
        '
        'GSISPremiumTextBox
        '
        Me.GSISPremiumTextBox.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.GSISPremiumTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.GenPayFinalBindingSource, "GSISPremium", True))
        Me.GSISPremiumTextBox.Font = New System.Drawing.Font("Century Schoolbook", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GSISPremiumTextBox.ForeColor = System.Drawing.Color.Black
        Me.GSISPremiumTextBox.Location = New System.Drawing.Point(194, 66)
        Me.GSISPremiumTextBox.Name = "GSISPremiumTextBox"
        Me.GSISPremiumTextBox.Size = New System.Drawing.Size(154, 23)
        Me.GSISPremiumTextBox.TabIndex = 15
        '
        'GSISSalaryLoanTextBox
        '
        Me.GSISSalaryLoanTextBox.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.GSISSalaryLoanTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.GenPayFinalBindingSource, "GSISSalaryLoan", True))
        Me.GSISSalaryLoanTextBox.Font = New System.Drawing.Font("Century Schoolbook", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GSISSalaryLoanTextBox.ForeColor = System.Drawing.Color.Black
        Me.GSISSalaryLoanTextBox.Location = New System.Drawing.Point(194, 100)
        Me.GSISSalaryLoanTextBox.Name = "GSISSalaryLoanTextBox"
        Me.GSISSalaryLoanTextBox.Size = New System.Drawing.Size(154, 23)
        Me.GSISSalaryLoanTextBox.TabIndex = 17
        '
        'GSISELTextBox
        '
        Me.GSISELTextBox.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.GSISELTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.GenPayFinalBindingSource, "GSISEL", True))
        Me.GSISELTextBox.Font = New System.Drawing.Font("Century Schoolbook", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GSISELTextBox.ForeColor = System.Drawing.Color.Black
        Me.GSISELTextBox.Location = New System.Drawing.Point(196, 141)
        Me.GSISELTextBox.Name = "GSISELTextBox"
        Me.GSISELTextBox.Size = New System.Drawing.Size(154, 23)
        Me.GSISELTextBox.TabIndex = 19
        '
        'GSISEMRGLTextBox
        '
        Me.GSISEMRGLTextBox.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.GSISEMRGLTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.GenPayFinalBindingSource, "GSISEMRGL", True))
        Me.GSISEMRGLTextBox.Font = New System.Drawing.Font("Century Schoolbook", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GSISEMRGLTextBox.ForeColor = System.Drawing.Color.Black
        Me.GSISEMRGLTextBox.Location = New System.Drawing.Point(196, 178)
        Me.GSISEMRGLTextBox.Name = "GSISEMRGLTextBox"
        Me.GSISEMRGLTextBox.Size = New System.Drawing.Size(154, 23)
        Me.GSISEMRGLTextBox.TabIndex = 21
        '
        'GSISPLTextBox
        '
        Me.GSISPLTextBox.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.GSISPLTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.GenPayFinalBindingSource, "GSISPL", True))
        Me.GSISPLTextBox.Font = New System.Drawing.Font("Century Schoolbook", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GSISPLTextBox.ForeColor = System.Drawing.Color.Black
        Me.GSISPLTextBox.Location = New System.Drawing.Point(196, 212)
        Me.GSISPLTextBox.Name = "GSISPLTextBox"
        Me.GSISPLTextBox.Size = New System.Drawing.Size(154, 23)
        Me.GSISPLTextBox.TabIndex = 23
        '
        'PagIbigPremTextBox
        '
        Me.PagIbigPremTextBox.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.PagIbigPremTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.GenPayFinalBindingSource, "PagIbigPrem", True))
        Me.PagIbigPremTextBox.Font = New System.Drawing.Font("Century Schoolbook", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PagIbigPremTextBox.ForeColor = System.Drawing.Color.Black
        Me.PagIbigPremTextBox.Location = New System.Drawing.Point(195, 246)
        Me.PagIbigPremTextBox.Name = "PagIbigPremTextBox"
        Me.PagIbigPremTextBox.Size = New System.Drawing.Size(154, 23)
        Me.PagIbigPremTextBox.TabIndex = 25
        '
        'PagIbigMLTextBox
        '
        Me.PagIbigMLTextBox.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.PagIbigMLTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.GenPayFinalBindingSource, "PagIbigML", True))
        Me.PagIbigMLTextBox.Font = New System.Drawing.Font("Century Schoolbook", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PagIbigMLTextBox.ForeColor = System.Drawing.Color.Black
        Me.PagIbigMLTextBox.Location = New System.Drawing.Point(195, 276)
        Me.PagIbigMLTextBox.Name = "PagIbigMLTextBox"
        Me.PagIbigMLTextBox.Size = New System.Drawing.Size(154, 23)
        Me.PagIbigMLTextBox.TabIndex = 27
        '
        'PagIbig2TextBox
        '
        Me.PagIbig2TextBox.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.PagIbig2TextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.GenPayFinalBindingSource, "PagIbig2", True))
        Me.PagIbig2TextBox.Font = New System.Drawing.Font("Century Schoolbook", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PagIbig2TextBox.ForeColor = System.Drawing.Color.Black
        Me.PagIbig2TextBox.Location = New System.Drawing.Point(196, 310)
        Me.PagIbig2TextBox.Name = "PagIbig2TextBox"
        Me.PagIbig2TextBox.Size = New System.Drawing.Size(154, 23)
        Me.PagIbig2TextBox.TabIndex = 29
        '
        'PhilHealthPremiunTextBox
        '
        Me.PhilHealthPremiunTextBox.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.PhilHealthPremiunTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.GenPayFinalBindingSource, "PhilHealthPremiun", True))
        Me.PhilHealthPremiunTextBox.Font = New System.Drawing.Font("Century Schoolbook", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PhilHealthPremiunTextBox.ForeColor = System.Drawing.Color.Black
        Me.PhilHealthPremiunTextBox.Location = New System.Drawing.Point(195, 346)
        Me.PhilHealthPremiunTextBox.Name = "PhilHealthPremiunTextBox"
        Me.PhilHealthPremiunTextBox.Size = New System.Drawing.Size(154, 23)
        Me.PhilHealthPremiunTextBox.TabIndex = 31
        '
        'LEAPTextBox
        '
        Me.LEAPTextBox.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.LEAPTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.GenPayFinalBindingSource, "LEAP", True))
        Me.LEAPTextBox.Font = New System.Drawing.Font("Century Schoolbook", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LEAPTextBox.ForeColor = System.Drawing.Color.Black
        Me.LEAPTextBox.Location = New System.Drawing.Point(194, 383)
        Me.LEAPTextBox.Name = "LEAPTextBox"
        Me.LEAPTextBox.Size = New System.Drawing.Size(154, 23)
        Me.LEAPTextBox.TabIndex = 33
        '
        'IGPTextBox
        '
        Me.IGPTextBox.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.IGPTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.GenPayFinalBindingSource, "IGP", True))
        Me.IGPTextBox.Font = New System.Drawing.Font("Century Schoolbook", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.IGPTextBox.ForeColor = System.Drawing.Color.Black
        Me.IGPTextBox.Location = New System.Drawing.Point(552, 212)
        Me.IGPTextBox.Name = "IGPTextBox"
        Me.IGPTextBox.Size = New System.Drawing.Size(140, 23)
        Me.IGPTextBox.TabIndex = 35
        '
        'FacultyUnionTextBox
        '
        Me.FacultyUnionTextBox.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.FacultyUnionTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.GenPayFinalBindingSource, "FacultyUnion", True))
        Me.FacultyUnionTextBox.Font = New System.Drawing.Font("Century Schoolbook", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FacultyUnionTextBox.ForeColor = System.Drawing.Color.Black
        Me.FacultyUnionTextBox.Location = New System.Drawing.Point(552, 246)
        Me.FacultyUnionTextBox.Name = "FacultyUnionTextBox"
        Me.FacultyUnionTextBox.Size = New System.Drawing.Size(140, 23)
        Me.FacultyUnionTextBox.TabIndex = 37
        '
        'RefundDisallowTextBox
        '
        Me.RefundDisallowTextBox.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.RefundDisallowTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.GenPayFinalBindingSource, "RefundDisallow", True))
        Me.RefundDisallowTextBox.Font = New System.Drawing.Font("Century Schoolbook", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RefundDisallowTextBox.ForeColor = System.Drawing.Color.Black
        Me.RefundDisallowTextBox.Location = New System.Drawing.Point(552, 276)
        Me.RefundDisallowTextBox.Name = "RefundDisallowTextBox"
        Me.RefundDisallowTextBox.Size = New System.Drawing.Size(140, 23)
        Me.RefundDisallowTextBox.TabIndex = 39
        '
        'TuitionTextBox
        '
        Me.TuitionTextBox.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.TuitionTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.GenPayFinalBindingSource, "Tuition", True))
        Me.TuitionTextBox.Font = New System.Drawing.Font("Century Schoolbook", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TuitionTextBox.ForeColor = System.Drawing.Color.Black
        Me.TuitionTextBox.Location = New System.Drawing.Point(552, 312)
        Me.TuitionTextBox.Name = "TuitionTextBox"
        Me.TuitionTextBox.Size = New System.Drawing.Size(140, 23)
        Me.TuitionTextBox.TabIndex = 41
        '
        'LBPPaymentTextBox
        '
        Me.LBPPaymentTextBox.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.LBPPaymentTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.GenPayFinalBindingSource, "LBPPayment", True))
        Me.LBPPaymentTextBox.Font = New System.Drawing.Font("Century Schoolbook", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LBPPaymentTextBox.ForeColor = System.Drawing.Color.Black
        Me.LBPPaymentTextBox.Location = New System.Drawing.Point(552, 347)
        Me.LBPPaymentTextBox.Name = "LBPPaymentTextBox"
        Me.LBPPaymentTextBox.Size = New System.Drawing.Size(140, 23)
        Me.LBPPaymentTextBox.TabIndex = 43
        '
        'CitySavingsTextBox
        '
        Me.CitySavingsTextBox.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.CitySavingsTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.GenPayFinalBindingSource, "CitySavings", True))
        Me.CitySavingsTextBox.Font = New System.Drawing.Font("Century Schoolbook", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CitySavingsTextBox.ForeColor = System.Drawing.Color.Black
        Me.CitySavingsTextBox.Location = New System.Drawing.Point(552, 383)
        Me.CitySavingsTextBox.Name = "CitySavingsTextBox"
        Me.CitySavingsTextBox.Size = New System.Drawing.Size(140, 23)
        Me.CitySavingsTextBox.TabIndex = 45
        '
        'TotalDeductionTextBox
        '
        Me.TotalDeductionTextBox.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.TotalDeductionTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.GenPayFinalBindingSource, "TotalDeduction", True))
        Me.TotalDeductionTextBox.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TotalDeductionTextBox.Location = New System.Drawing.Point(178, 20)
        Me.TotalDeductionTextBox.Name = "TotalDeductionTextBox"
        Me.TotalDeductionTextBox.ReadOnly = True
        Me.TotalDeductionTextBox.Size = New System.Drawing.Size(152, 22)
        Me.TotalDeductionTextBox.TabIndex = 47
        '
        'NetAmountTextBox
        '
        Me.NetAmountTextBox.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.NetAmountTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.GenPayFinalBindingSource, "NetAmount", True))
        Me.NetAmountTextBox.Location = New System.Drawing.Point(184, 16)
        Me.NetAmountTextBox.Name = "NetAmountTextBox"
        Me.NetAmountTextBox.ReadOnly = True
        Me.NetAmountTextBox.Size = New System.Drawing.Size(140, 26)
        Me.NetAmountTextBox.TabIndex = 49
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox1.Controls.Add(NoLabel)
        Me.GroupBox1.Controls.Add(Me.NoTextBox)
        Me.GroupBox1.Controls.Add(PlantIDLabel)
        Me.GroupBox1.Controls.Add(Me.PlantIDTextBox)
        Me.GroupBox1.Controls.Add(Me.EmployeeNameTextBox)
        Me.GroupBox1.Controls.Add(EmployeeNameLabel)
        Me.GroupBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(16, 210)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(320, 155)
        Me.GroupBox1.TabIndex = 50
        Me.GroupBox1.TabStop = False
        '
        'NoTextBox
        '
        Me.NoTextBox.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.NoTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.GenPayFinalBindingSource, "No", True))
        Me.NoTextBox.Location = New System.Drawing.Point(161, 101)
        Me.NoTextBox.Name = "NoTextBox"
        Me.NoTextBox.Size = New System.Drawing.Size(45, 22)
        Me.NoTextBox.TabIndex = 5
        '
        'GroupBox2
        '
        Me.GroupBox2.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox2.Controls.Add(Me.GroupBox3)
        Me.GroupBox2.Controls.Add(Me.BasicTextBox)
        Me.GroupBox2.Controls.Add(Me.PERATextBox)
        Me.GroupBox2.Controls.Add(PERALabel)
        Me.GroupBox2.Controls.Add(BasicLabel)
        Me.GroupBox2.Location = New System.Drawing.Point(16, 385)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(320, 143)
        Me.GroupBox2.TabIndex = 51
        Me.GroupBox2.TabStop = False
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.GrossAmountTextBox)
        Me.GroupBox3.Controls.Add(GrossAmountLabel)
        Me.GroupBox3.Location = New System.Drawing.Point(7, 82)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(307, 55)
        Me.GroupBox3.TabIndex = 52
        Me.GroupBox3.TabStop = False
        '
        'GroupBox4
        '
        Me.GroupBox4.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox4.Controls.Add(Me.Button3)
        Me.GroupBox4.Controls.Add(WtaxLabel)
        Me.GroupBox4.Controls.Add(Me.GroupBox5)
        Me.GroupBox4.Controls.Add(Me.WtaxTextBox)
        Me.GroupBox4.Controls.Add(GSISPremiumLabel)
        Me.GroupBox4.Controls.Add(GSISSalaryLoanLabel)
        Me.GroupBox4.Controls.Add(GSISELLabel)
        Me.GroupBox4.Controls.Add(GSISEMRGLLabel)
        Me.GroupBox4.Controls.Add(Me.GroupBox6)
        Me.GroupBox4.Controls.Add(CitySavingsLabel)
        Me.GroupBox4.Controls.Add(GSISPLLabel)
        Me.GroupBox4.Controls.Add(PagIbigPremLabel)
        Me.GroupBox4.Controls.Add(LBPPaymentLabel)
        Me.GroupBox4.Controls.Add(PagIbigMLLabel)
        Me.GroupBox4.Controls.Add(PagIbig2Label)
        Me.GroupBox4.Controls.Add(TuitionLabel)
        Me.GroupBox4.Controls.Add(PhilHealthPremiunLabel)
        Me.GroupBox4.Controls.Add(Me.CitySavingsTextBox)
        Me.GroupBox4.Controls.Add(LEAPLabel)
        Me.GroupBox4.Controls.Add(Me.LBPPaymentTextBox)
        Me.GroupBox4.Controls.Add(RefundDisallowLabel)
        Me.GroupBox4.Controls.Add(Me.TuitionTextBox)
        Me.GroupBox4.Controls.Add(IGPLabel)
        Me.GroupBox4.Controls.Add(Me.RefundDisallowTextBox)
        Me.GroupBox4.Controls.Add(FacultyUnionLabel)
        Me.GroupBox4.Controls.Add(Me.FacultyUnionTextBox)
        Me.GroupBox4.Controls.Add(Me.GSISPremiumTextBox)
        Me.GroupBox4.Controls.Add(Me.IGPTextBox)
        Me.GroupBox4.Controls.Add(Me.GSISSalaryLoanTextBox)
        Me.GroupBox4.Controls.Add(Me.LEAPTextBox)
        Me.GroupBox4.Controls.Add(Me.GSISELTextBox)
        Me.GroupBox4.Controls.Add(Me.PhilHealthPremiunTextBox)
        Me.GroupBox4.Controls.Add(Me.GSISEMRGLTextBox)
        Me.GroupBox4.Controls.Add(Me.PagIbig2TextBox)
        Me.GroupBox4.Controls.Add(Me.GSISPLTextBox)
        Me.GroupBox4.Controls.Add(Me.PagIbigMLTextBox)
        Me.GroupBox4.Controls.Add(Me.PagIbigPremTextBox)
        Me.GroupBox4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox4.Location = New System.Drawing.Point(358, 89)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(747, 478)
        Me.GroupBox4.TabIndex = 52
        Me.GroupBox4.TabStop = False
        '
        'Button3
        '
        Me.Button3.BackgroundImage = CType(resources.GetObject("Button3.BackgroundImage"), System.Drawing.Image)
        Me.Button3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.Button3.Font = New System.Drawing.Font("Century Schoolbook", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button3.Location = New System.Drawing.Point(391, 28)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(309, 165)
        Me.Button3.TabIndex = 233
        Me.Button3.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Button3.UseVisualStyleBackColor = True
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.TotalDeductionTextBox)
        Me.GroupBox5.Controls.Add(TotalDeductionLabel)
        Me.GroupBox5.Location = New System.Drawing.Point(17, 410)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(344, 56)
        Me.GroupBox5.TabIndex = 53
        Me.GroupBox5.TabStop = False
        '
        'GroupBox6
        '
        Me.GroupBox6.Controls.Add(NetAmountLabel)
        Me.GroupBox6.Controls.Add(Me.NetAmountTextBox)
        Me.GroupBox6.Font = New System.Drawing.Font("MS Reference Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox6.Location = New System.Drawing.Point(367, 410)
        Me.GroupBox6.Name = "GroupBox6"
        Me.GroupBox6.Size = New System.Drawing.Size(360, 56)
        Me.GroupBox6.TabIndex = 53
        Me.GroupBox6.TabStop = False
        '
        'PrintPreviewDialog1
        '
        Me.PrintPreviewDialog1.AutoScrollMargin = New System.Drawing.Size(0, 0)
        Me.PrintPreviewDialog1.AutoScrollMinSize = New System.Drawing.Size(0, 0)
        Me.PrintPreviewDialog1.ClientSize = New System.Drawing.Size(400, 300)
        Me.PrintPreviewDialog1.Document = Me.PrintDocument1
        Me.PrintPreviewDialog1.Enabled = True
        Me.PrintPreviewDialog1.Icon = CType(resources.GetObject("PrintPreviewDialog1.Icon"), System.Drawing.Icon)
        Me.PrintPreviewDialog1.Name = "PrintPreviewDialog1"
        Me.PrintPreviewDialog1.Visible = False
        '
        'Button4
        '
        Me.Button4.Font = New System.Drawing.Font("Palatino Linotype", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button4.Image = CType(resources.GetObject("Button4.Image"), System.Drawing.Image)
        Me.Button4.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button4.Location = New System.Drawing.Point(1004, 618)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(117, 43)
        Me.Button4.TabIndex = 237
        Me.Button4.Text = "         &View Data"
        Me.Button4.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Button4.UseVisualStyleBackColor = True
        '
        'save
        '
        Me.save.Font = New System.Drawing.Font("Century Schoolbook", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.save.Image = CType(resources.GetObject("save.Image"), System.Drawing.Image)
        Me.save.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.save.Location = New System.Drawing.Point(743, 618)
        Me.save.Name = "save"
        Me.save.Size = New System.Drawing.Size(99, 43)
        Me.save.TabIndex = 235
        Me.save.Text = "    &Save"
        Me.save.UseVisualStyleBackColor = True
        '
        'btnDeleteJHS
        '
        Me.btnDeleteJHS.Font = New System.Drawing.Font("Century Schoolbook", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDeleteJHS.Image = CType(resources.GetObject("btnDeleteJHS.Image"), System.Drawing.Image)
        Me.btnDeleteJHS.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnDeleteJHS.Location = New System.Drawing.Point(881, 618)
        Me.btnDeleteJHS.Name = "btnDeleteJHS"
        Me.btnDeleteJHS.Size = New System.Drawing.Size(99, 43)
        Me.btnDeleteJHS.TabIndex = 236
        Me.btnDeleteJHS.Text = "      &Remove"
        Me.btnDeleteJHS.UseVisualStyleBackColor = True
        '
        'Button10
        '
        Me.Button10.Font = New System.Drawing.Font("Century Schoolbook", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button10.Image = CType(resources.GetObject("Button10.Image"), System.Drawing.Image)
        Me.Button10.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button10.Location = New System.Drawing.Point(355, 618)
        Me.Button10.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.Button10.Name = "Button10"
        Me.Button10.Size = New System.Drawing.Size(108, 43)
        Me.Button10.TabIndex = 234
        Me.Button10.Text = "&Previous"
        Me.Button10.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Button10.UseVisualStyleBackColor = True
        '
        'btnLogin
        '
        Me.btnLogin.Font = New System.Drawing.Font("Century Schoolbook", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnLogin.Image = CType(resources.GetObject("btnLogin.Image"), System.Drawing.Image)
        Me.btnLogin.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnLogin.Location = New System.Drawing.Point(607, 618)
        Me.btnLogin.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btnLogin.Name = "btnLogin"
        Me.btnLogin.Size = New System.Drawing.Size(99, 43)
        Me.btnLogin.TabIndex = 232
        Me.btnLogin.Text = "&Add New"
        Me.btnLogin.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnLogin.UseVisualStyleBackColor = True
        '
        'Button11
        '
        Me.Button11.Font = New System.Drawing.Font("Century Schoolbook", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button11.Image = CType(resources.GetObject("Button11.Image"), System.Drawing.Image)
        Me.Button11.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Button11.Location = New System.Drawing.Point(483, 618)
        Me.Button11.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.Button11.Name = "Button11"
        Me.Button11.Size = New System.Drawing.Size(92, 43)
        Me.Button11.TabIndex = 233
        Me.Button11.Text = "  &Next"
        Me.Button11.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button11.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Font = New System.Drawing.Font("Century Schoolbook", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.Image = CType(resources.GetObject("Button2.Image"), System.Drawing.Image)
        Me.Button2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button2.Location = New System.Drawing.Point(670, 574)
        Me.Button2.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(102, 37)
        Me.Button2.TabIndex = 238
        Me.Button2.Text = "&Compute"
        Me.Button2.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.White
        Me.Button1.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button1.Font = New System.Drawing.Font("Century Schoolbook", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.Image = CType(resources.GetObject("Button1.Image"), System.Drawing.Image)
        Me.Button1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button1.Location = New System.Drawing.Point(248, 622)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(88, 36)
        Me.Button1.TabIndex = 244
        Me.Button1.Text = "&Back"
        Me.Button1.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Button1.UseVisualStyleBackColor = False
        '
        'LinkLabel1
        '
        Me.LinkLabel1.AutoSize = True
        Me.LinkLabel1.BackColor = System.Drawing.Color.Transparent
        Me.LinkLabel1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.LinkLabel1.Font = New System.Drawing.Font("Century Schoolbook", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LinkLabel1.LinkColor = System.Drawing.Color.Black
        Me.LinkLabel1.Location = New System.Drawing.Point(479, 50)
        Me.LinkLabel1.Name = "LinkLabel1"
        Me.LinkLabel1.Size = New System.Drawing.Size(185, 23)
        Me.LinkLabel1.TabIndex = 245
        Me.LinkLabel1.TabStop = True
        Me.LinkLabel1.Text = "Payment Details:-"
        Me.LinkLabel1.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(12, 21)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(186, 111)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox1.TabIndex = 246
        Me.PictureBox1.TabStop = False
        '
        'frmpayslip
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Window
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(1148, 670)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.LinkLabel1)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.save)
        Me.Controls.Add(Me.btnDeleteJHS)
        Me.Controls.Add(Me.Button10)
        Me.Controls.Add(Me.btnLogin)
        Me.Controls.Add(Me.Button11)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.GroupBox4)
        Me.Cursor = System.Windows.Forms.Cursors.Hand
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Name = "frmpayslip"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Payment Details:-"
        CType(Me.GenerallPayrollDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.GenPayFinalBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox5.PerformLayout()
        Me.GroupBox6.ResumeLayout(False)
        Me.GroupBox6.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents GenerallPayrollDataSet As sdssuHOLLISTICPayrollsystem.GenerallPayrollDataSet
    Friend WithEvents GenPayFinalBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents GenPayFinalTableAdapter As sdssuHOLLISTICPayrollsystem.GenerallPayrollDataSetTableAdapters.GenPayFinalTableAdapter
    Friend WithEvents TableAdapterManager As sdssuHOLLISTICPayrollsystem.GenerallPayrollDataSetTableAdapters.TableAdapterManager
    Friend WithEvents PlantIDTextBox As System.Windows.Forms.TextBox
    Friend WithEvents EmployeeNameTextBox As System.Windows.Forms.TextBox
    Friend WithEvents BasicTextBox As System.Windows.Forms.TextBox
    Friend WithEvents PERATextBox As System.Windows.Forms.TextBox
    Friend WithEvents GrossAmountTextBox As System.Windows.Forms.TextBox
    Friend WithEvents WtaxTextBox As System.Windows.Forms.TextBox
    Friend WithEvents GSISPremiumTextBox As System.Windows.Forms.TextBox
    Friend WithEvents GSISSalaryLoanTextBox As System.Windows.Forms.TextBox
    Friend WithEvents GSISELTextBox As System.Windows.Forms.TextBox
    Friend WithEvents GSISEMRGLTextBox As System.Windows.Forms.TextBox
    Friend WithEvents GSISPLTextBox As System.Windows.Forms.TextBox
    Friend WithEvents PagIbigPremTextBox As System.Windows.Forms.TextBox
    Friend WithEvents PagIbigMLTextBox As System.Windows.Forms.TextBox
    Friend WithEvents PagIbig2TextBox As System.Windows.Forms.TextBox
    Friend WithEvents PhilHealthPremiunTextBox As System.Windows.Forms.TextBox
    Friend WithEvents LEAPTextBox As System.Windows.Forms.TextBox
    Friend WithEvents IGPTextBox As System.Windows.Forms.TextBox
    Friend WithEvents FacultyUnionTextBox As System.Windows.Forms.TextBox
    Friend WithEvents RefundDisallowTextBox As System.Windows.Forms.TextBox
    Friend WithEvents TuitionTextBox As System.Windows.Forms.TextBox
    Friend WithEvents LBPPaymentTextBox As System.Windows.Forms.TextBox
    Friend WithEvents CitySavingsTextBox As System.Windows.Forms.TextBox
    Friend WithEvents TotalDeductionTextBox As System.Windows.Forms.TextBox
    Friend WithEvents NetAmountTextBox As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox5 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox6 As System.Windows.Forms.GroupBox
    Friend WithEvents Number1DataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents PrintDocument1 As System.Drawing.Printing.PrintDocument
    Friend WithEvents PrintPreviewDialog1 As System.Windows.Forms.PrintPreviewDialog
    Friend WithEvents NoTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents save As System.Windows.Forms.Button
    Friend WithEvents btnDeleteJHS As System.Windows.Forms.Button
    Friend WithEvents Button10 As System.Windows.Forms.Button
    Friend WithEvents btnLogin As System.Windows.Forms.Button
    Friend WithEvents Button11 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents LinkLabel1 As System.Windows.Forms.LinkLabel
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
End Class
