﻿Public Class frmpayslip

    Private Sub GenPayFinalBindingNavigatorSaveItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Me.Validate()
        Me.GenPayFinalBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.GenerallPayrollDataSet)

    End Sub

    Private Sub frmpayslip_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'GenerallPayrollDataSet.GenPayFinal' table. You can move, or remove it, as needed.
        Me.GenPayFinalTableAdapter.Fill(Me.GenerallPayrollDataSet.GenPayFinal)

    End Sub



    Private Sub Button10_Click(sender As Object, e As EventArgs) Handles Button10.Click
        GenPayFinalBindingSource.MovePrevious()
    End Sub

    Private Sub Button11_Click(sender As Object, e As EventArgs) Handles Button11.Click
        GenPayFinalBindingSource.MoveNext()
    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles btnDeleteJHS.Click
        Try
            If PlantIDTextBox.Text = "" Then
                MessageBox.Show("Please select employee id", "Entry", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                Exit Sub
            End If
            If PlantIDTextBox.Text.Count > 0 Then
                If MessageBox.Show("Do you really want to delete the record?" & vbCrLf & "You can not restore the record" & vbCrLf & "It will delete record permanently" & vbCrLf & "related to selected employee", "Warning!!!", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) = Windows.Forms.DialogResult.Yes Then
                    GenPayFinalBindingSource.RemoveCurrent()
                    Me.TableAdapterManager.UpdateAll(Me.GenerallPayrollDataSet)
                End If
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub btnLogin_Click_1(sender As Object, e As EventArgs) Handles btnLogin.Click



        Try
            If MsgBox("Do you want to add new employee?", vbYesNo + vbQuestion) = vbYes Then
                GenPayFinalBindingSource.AddNew()
                Me.TableAdapterManager.UpdateAll(Me.GenerallPayrollDataSet)
                MessageBox.Show("You can now input...")
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub save_Click(sender As Object, e As EventArgs) Handles save.Click
        Me.Validate()
        Me.GenPayFinalBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.GenerallPayrollDataSet)
        MessageBox.Show("Successfully Added")
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        TotalDeductionTextBox.Text = Val(WtaxTextBox.Text) + Val(GSISPremiumTextBox.Text) + Val(GSISSalaryLoanTextBox.Text) + Val(GSISELTextBox.Text) + Val(GSISEMRGLTextBox.Text) + Val(GSISPLTextBox.Text) + Val(PagIbigPremTextBox.Text) + Val(PagIbigMLTextBox.Text) + Val(PagIbig2TextBox.Text) + Val(PhilHealthPremiunTextBox.Text) + Val(LEAPTextBox.Text) + Val(IGPTextBox.Text) + Val(FacultyUnionTextBox.Text) + Val(RefundDisallowTextBox.Text) + Val(TuitionTextBox.Text) + Val(LBPPaymentTextBox.Text) + Val(CitySavingsTextBox.Text)
        GrossAmountTextBox.Text = Val(BasicTextBox.Text) + Val(PERATextBox.Text)
        NetAmountTextBox.Text = Val(GrossAmountTextBox.Text) - Val(TotalDeductionTextBox.Text)

        NetAmountTextBox.Text = FormatCurrency(NetAmountTextBox.Text)
        TotalDeductionTextBox.Text = FormatCurrency(TotalDeductionTextBox.Text)
        GrossAmountTextBox.Text = FormatCurrency(GrossAmountTextBox.Text)
        MessageBox.Show("Successfully Computed")
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        View.Show()

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click


        Me.TableAdapterManager.UpdateAll(Me.GenerallPayrollDataSet)
        Me.Close()

    End Sub


   
End Class